"""
NITB DSP Control Matrix — v0.6
Naked In The Booth / 7 Virtues Entertainment

NEW IN v0.6:
  - Full page scrollable with mousewheel anywhere
  - Master range -inf to +40 dB
  - Separate GAIN KNOB (rotary) alongside master fader
  - Full-spectrum live RTA overlaid on EQ canvas (see every frequency live)
  - Routing screen per profile — shows IN source, signal path, OUT device
  - Preset list panel — scrollable, click to load
  - Add Profile saves routing info (in device, out device) with the DSP state
"""

import subprocess, sys, os

REQUIRED = {
    "numpy":"numpy","scipy":"scipy",
    "sounddevice":"sounddevice","customtkinter":"customtkinter",
    "pycaw":"pycaw","comtypes":"comtypes",
}

def install_missing():
    import importlib, importlib.util
    missing = [p for m,p in REQUIRED.items() if not importlib.util.find_spec(m)]
    if missing:
        print(f"[NITB] Installing: {', '.join(missing)} ...")
        subprocess.check_call([sys.executable,"-m","pip","install","--quiet",*missing])
        print("[NITB] Ready.\n")

install_missing()

import json, threading, math
from pathlib import Path
import numpy as np
import sounddevice as sd
import customtkinter as ctk
import tkinter as tk
from tkinter import filedialog, simpledialog, messagebox

try:
    from pycaw.pycaw import (AudioUtilities, IAudioEndpointVolume, ISimpleAudioVolume)
    from ctypes import cast, POINTER
    from comtypes import CLSCTX_ALL
    PYCAW_OK = True
except Exception as e:
    print(f"[NITB] pycaw: {e}"); PYCAW_OK = False

from scipy.signal import lfilter

# ── Theme ──────────────────────────────────────────────────────────────────────
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("dark-blue")

BG      = "#080808"
PANEL   = "#0d0d0d"
CARD    = "#141414"
BORDER  = "#1e1e1e"
ACCENT  = "#00e5ff"
WARM    = "#ff6b00"
GREEN   = "#00c853"
DIM     = "#242424"
TEXT    = "#e0e0e0"
TEXTDIM = "#444444"
RED     = "#ff2020"
YELLOW  = "#ffe000"
PURPLE  = "#cc44ff"
SEL     = "#002833"

FM   = ("Courier New", 10)
FMS  = ("Courier New", 9)
FMT  = ("Courier New", 8)
FL   = ("Segoe UI", 9)
FH   = ("Segoe UI", 10, "bold")
FT   = ("Segoe UI", 13, "bold")
FB   = ("Courier New", 20, "bold")

SR    = 48000
BLOCK = 512

GEQ_FREQS = [
    20,25,31,40,50,63,80,100,125,160,
    200,250,315,400,500,630,800,1000,
    1250,1600,2000,2500,3150,4000,5000,
    6300,8000,10000,12500,16000,20000,25000
]
GEQ_MAX  = 12.0
GEQ_STEP = 0.5

MASTER_MIN = -90.0
MASTER_MAX = +40.0   # +40 dB above unity
GAIN_MIN   =   0.0
GAIN_MAX   = +40.0

APO_PATHS = [
    r"C:\Program Files\EqualizerAPO\config",
    r"C:\Program Files (x86)\EqualizerAPO\config",
]

# ── Math ───────────────────────────────────────────────────────────────────────
def db2lin(db):  return 10.0**(db/20.0)
def lin2db(x):   return 20.0*math.log10(max(abs(float(x)),1e-10))
def norm(db, floor=-60.0): return max(0.0, min(1.0,(db-floor)/abs(floor)))
def peak_db(b):
    if b is None or len(b)==0: return -120.0
    return lin2db(float(np.max(np.abs(b))))
def rms_db(b):
    if b is None or len(b)==0: return -120.0
    return lin2db(float(np.sqrt(np.mean(np.array(b,dtype=np.float64)**2))))

# ── Biquad ─────────────────────────────────────────────────────────────────────
def biquad_hpf(fc,Q=0.707):
    w0=2*math.pi*fc/SR; al=math.sin(w0)/(2*Q)
    b=[(1+math.cos(w0))/2,-(1+math.cos(w0)),(1+math.cos(w0))/2]
    a=[1+al,-2*math.cos(w0),1-al]
    return np.array(b)/a[0],np.array(a)/a[0]

def biquad_lpf(fc,Q=0.707):
    w0=2*math.pi*fc/SR; al=math.sin(w0)/(2*Q)
    b=[(1-math.cos(w0))/2,1-math.cos(w0),(1-math.cos(w0))/2]
    a=[1+al,-2*math.cos(w0),1-al]
    return np.array(b)/a[0],np.array(a)/a[0]

# ── Windows volume ─────────────────────────────────────────────────────────────
class MasterVolume:
    def __init__(self):
        self._i=None; self._ok=False
        if not PYCAW_OK: return
        try:
            dev=AudioUtilities.GetSpeakers()
            i=dev.Activate(IAudioEndpointVolume._iid_,CLSCTX_ALL,None)
            self._i=cast(i,POINTER(IAudioEndpointVolume)); self._ok=True
        except Exception as e: print(f"[Vol] {e}")
    ok=property(lambda self:self._ok)
    def get(self):
        if self._ok:
            try: return float(self._i.GetMasterVolumeLevelScalar())
            except: pass
        return 1.0
    def set(self,s):
        if self._ok:
            try: self._i.SetMasterVolumeLevelScalar(float(np.clip(s,0,1)),None)
            except: pass
    def get_mute(self):
        if self._ok:
            try: return bool(self._i.GetMute())
            except: pass
        return False
    def set_mute(self,v):
        if self._ok:
            try: self._i.SetMute(int(v),None)
            except: pass

class AppSessions:
    def get(self):
        if not PYCAW_OK: return []
        try:
            return [(s.Process.name().replace(".exe","").title(),
                     s.Process.name(),s)
                    for s in AudioUtilities.GetAllSessions() if s.Process]
        except: return []
    def set_vol(self,sess,s):
        try: sess._ctl.QueryInterface(ISimpleAudioVolume).SetMasterVolume(float(np.clip(s,0,1)),None)
        except: pass
    def get_vol(self,sess):
        try: return float(sess._ctl.QueryInterface(ISimpleAudioVolume).GetMasterVolume())
        except: return 1.0

# ── APO writer ─────────────────────────────────────────────────────────────────
class APOWriter:
    def __init__(self):
        self.dir=None; self.path=None
        for p in APO_PATHS:
            if os.path.isdir(p):
                self.dir=p; self.path=os.path.join(p,"NITB_DSP.txt"); break
        self.ok=self.path is not None
        if self.ok: self._link()
    def _link(self):
        main=os.path.join(self.dir,"config.txt"); tag="Include: NITB_DSP.txt"
        try:
            txt=open(main).read() if os.path.exists(main) else ""
            if tag not in txt: open(main,"a").write(f"\n{tag}\n")
        except: pass
    def write(self,st):
        if not self.ok: return
        lines=["# NITB DSP Control Matrix",""]
        lines.append("Mute: on" if st.master_mute else "Mute: off")
        # Total gain = master_db + gain_db, capped at APO's +12 preamp limit
        total=min(st.master_db+st.gain_db, 12.0)
        if abs(total)>0.05: lines.append(f"Preamp: {total:.1f} dB")
        if st.hpf_on: lines.append(f"Filter: ON HP Butterworth Fc {st.hpf_freq} Hz")
        if st.lpf_on: lines.append(f"Filter: ON LP Butterworth Fc {st.lpf_freq} Hz")
        if st.geq_enabled:
            for f,g in st.geq_gains.items():
                if abs(g)>0.05:
                    lines.append(f"Filter: ON PK Fc {f} Hz Gain {g:+.1f} dB Q 2.87")
        if st.lim_enabled: lines.append(f"Preamp: {min(0.0,st.lim_thr):.1f} dB")
        try: open(self.path,"w").write("\n".join(lines)+"\n")
        except Exception as e: print(f"[APO] {e}")

# ── Analyzer ───────────────────────────────────────────────────────────────────
class Analyzer:
    """WASAPI loopback capture — peak, rms, clip, full FFT spectrum."""
    FFT_SIZE = 4096

    def __init__(self):
        self._lock=threading.Lock()
        self._peak=-120.0; self._rms=-120.0; self._clip=False
        self._fft_db=np.full(self.FFT_SIZE//2+1,-120.0)
        self._freqs=np.fft.rfftfreq(self.FFT_SIZE,1.0/SR)
        self._buf=np.zeros(self.FFT_SIZE)
        self._stream=None

    def start(self,device_idx=None):
        self.stop()
        def cb(indata,frames,t,status):
            mono=(indata[:,0] if indata.ndim>1 else indata.ravel()).astype(np.float64)
            n=len(mono)
            self._buf=np.roll(self._buf,-n); self._buf[-n:]=mono
            mag=np.abs(np.fft.rfft(self._buf*np.hanning(self.FFT_SIZE)))
            db=20*np.log10(np.maximum(mag/(self.FFT_SIZE/2),1e-10))
            with self._lock:
                self._peak=peak_db(mono); self._rms=rms_db(mono)
                self._clip=self._peak>=0.0; self._fft_db=db
        try:
            kw=dict(channels=1,samplerate=SR,blocksize=BLOCK,callback=cb)
            if device_idx is not None: kw["device"]=device_idx
            self._stream=sd.InputStream(**kw); self._stream.start()
        except Exception as e: print(f"[Analyzer] {e}")

    def stop(self):
        if self._stream:
            try: self._stream.stop(); self._stream.close()
            except: pass
            self._stream=None

    def read(self):
        with self._lock:
            return self._peak,self._rms,self._clip,self._freqs.copy(),self._fft_db.copy()

# ── DSP State ──────────────────────────────────────────────────────────────────
class DSPState:
    def __init__(self):
        self.master_db=0.0; self.gain_db=0.0; self.master_mute=False
        self.geq_gains={f:0.0 for f in GEQ_FREQS}; self.geq_enabled=True
        self.hpf_on=False; self.hpf_freq=80
        self.lpf_on=False; self.lpf_freq=18000
        self.comp_enabled=False; self.comp_thr=-18.0
        self.comp_ratio=2.5; self.comp_atk=10.0
        self.comp_rel=150.0; self.comp_makeup=0.0
        self.lim_enabled=True; self.lim_thr=-3.0
        self.preset_name="Default"
        self.route_in="System Audio"; self.route_out="Realtek 3.5mm"
        self.route_notes=""

    def to_dict(self):
        return dict(
            preset_name=self.preset_name,
            master_db=self.master_db, gain_db=self.gain_db,
            master_mute=self.master_mute,
            geq_gains={str(k):v for k,v in self.geq_gains.items()},
            geq_enabled=self.geq_enabled,
            hpf_on=self.hpf_on, hpf_freq=self.hpf_freq,
            lpf_on=self.lpf_on, lpf_freq=self.lpf_freq,
            comp_enabled=self.comp_enabled, comp_thr=self.comp_thr,
            comp_ratio=self.comp_ratio, comp_atk=self.comp_atk,
            comp_rel=self.comp_rel, comp_makeup=self.comp_makeup,
            lim_enabled=self.lim_enabled, lim_thr=self.lim_thr,
            route_in=self.route_in, route_out=self.route_out,
            route_notes=self.route_notes,
        )

    def from_dict(self,d):
        self.preset_name =d.get("preset_name",self.preset_name)
        self.master_db   =float(d.get("master_db",0.0))
        self.gain_db     =float(d.get("gain_db",0.0))
        self.master_mute =bool(d.get("master_mute",False))
        raw=d.get("geq_gains",{})
        self.geq_gains={int(k):float(v) for k,v in raw.items()}
        for f in GEQ_FREQS:
            if f not in self.geq_gains: self.geq_gains[f]=0.0
        self.geq_enabled =bool(d.get("geq_enabled",True))
        self.hpf_on      =bool(d.get("hpf_on",False))
        self.hpf_freq    =int(d.get("hpf_freq",80))
        self.lpf_on      =bool(d.get("lpf_on",False))
        self.lpf_freq    =int(d.get("lpf_freq",18000))
        self.comp_enabled=bool(d.get("comp_enabled",False))
        self.comp_thr    =float(d.get("comp_thr",-18.0))
        self.comp_ratio  =float(d.get("comp_ratio",2.5))
        self.comp_atk    =float(d.get("comp_atk",10.0))
        self.comp_rel    =float(d.get("comp_rel",150.0))
        self.comp_makeup =float(d.get("comp_makeup",0.0))
        self.lim_enabled =bool(d.get("lim_enabled",True))
        self.lim_thr     =float(d.get("lim_thr",-3.0))
        self.route_in    =d.get("route_in","System Audio")
        self.route_out   =d.get("route_out","Realtek 3.5mm")
        self.route_notes =d.get("route_notes","")

# ── Built-in profiles ──────────────────────────────────────────────────────────
def _flat(): return {str(f):0.0 for f in GEQ_FREQS}

BUILTIN_PROFILES = {
    "Flat": dict(preset_name="Flat",master_db=0.0,gain_db=0.0,master_mute=False,
        geq_gains=_flat(),geq_enabled=True,
        hpf_on=False,hpf_freq=20,lpf_on=False,lpf_freq=20000,
        comp_enabled=False,comp_thr=-18.0,comp_ratio=2.5,
        lim_enabled=True,lim_thr=-1.0,
        route_in="System Audio (all apps)",route_out="Realtek 3.5mm → Speakers",
        route_notes="All system audio → flat → Realtek output. No processing."),
    "Studio": dict(preset_name="Studio",master_db=-6.0,gain_db=0.0,master_mute=False,
        geq_gains=_flat(),geq_enabled=True,
        hpf_on=True,hpf_freq=40,lpf_on=False,lpf_freq=20000,
        comp_enabled=False,comp_thr=-18.0,comp_ratio=2.0,
        lim_enabled=True,lim_thr=-3.0,
        route_in="System Audio (all apps)",route_out="Realtek 3.5mm → Studio Monitors",
        route_notes="Flat EQ, -6dB master headroom, HPF at 40Hz removes sub rumble. Reference monitoring."),
    "DJ Booth": dict(preset_name="DJ Booth",master_db=0.0,gain_db=0.0,master_mute=False,
        geq_gains={
            "20":0.0,"25":0.0,"31":1.5,"40":2.5,"50":3.0,
            "63":3.0,"80":2.5,"100":2.0,"125":1.5,"160":1.0,
            "200":0.5,"250":0.0,"315":0.0,"400":0.0,"500":0.0,
            "630":0.0,"800":-0.5,"1000":-0.5,"1250":-1.0,"1600":-1.0,
            "2000":-1.5,"2500":-1.5,"3150":-1.5,"4000":-1.5,"5000":-1.0,
            "6300":-1.0,"8000":-2.0,"10000":-2.5,"12500":-3.0,
            "16000":-3.0,"20000":-3.0,"25000":-3.0},
        geq_enabled=True,hpf_on=True,hpf_freq=30,lpf_on=False,lpf_freq=20000,
        comp_enabled=True,comp_thr=-12.0,comp_ratio=3.0,
        lim_enabled=True,lim_thr=-3.0,
        route_in="Rekordbox / Serato / System Audio",
        route_out="Realtek 3.5mm → Crown / USB Interface → PA",
        route_notes="Club curve: +3dB sub shelf, boosted 50–125Hz punch. High end rolled off above 8k. Compressor glues the low end. Signal: PC → Realtek AUX → Crown Macro-Tech → Sub + Tops."),
    "Live Playback": dict(preset_name="Live Playback",master_db=-6.0,gain_db=0.0,master_mute=False,
        geq_gains={
            "20":0.0,"25":0.0,"31":0.0,"40":0.0,"50":0.0,"63":0.0,
            "80":1.0,"100":1.0,"125":0.5,"160":0.0,"200":0.0,"250":0.0,
            "315":0.5,"400":0.5,"500":0.5,"630":0.0,"800":0.0,"1000":0.0,
            "1250":0.5,"1600":0.5,"2000":0.5,"2500":0.0,"3150":0.0,
            "4000":0.0,"5000":0.0,"6300":0.0,"8000":0.0,"10000":0.0,
            "12500":0.0,"16000":0.0,"20000":0.0,"25000":0.0},
        geq_enabled=True,hpf_on=True,hpf_freq=80,lpf_on=True,lpf_freq=16000,
        comp_enabled=True,comp_thr=-18.0,comp_ratio=2.0,
        lim_enabled=True,lim_thr=-3.0,
        route_in="QLab / MagicScroll / Playback Software",
        route_out="USB Interface → M32 USB Return → FOH",
        route_notes="Broadcast-safe feed. HPF 80Hz removes PA rumble. LPF 16kHz removes digital harshness. Signal: PC → USB → M32 USB Return → Main Mix → FOH. -6dB master leaves headroom for FOH engineer."),
    "Broadcast": dict(preset_name="Broadcast",master_db=-3.0,gain_db=0.0,master_mute=False,
        geq_gains={
            "20":0.0,"25":0.0,"31":0.0,"40":0.0,"50":0.0,"63":0.0,
            "80":0.0,"100":0.0,"125":0.5,"160":0.5,"200":1.0,"250":1.0,
            "315":1.5,"400":1.5,"500":2.0,"630":2.0,"800":1.5,"1000":1.5,
            "1250":1.0,"1600":1.0,"2000":0.5,"2500":0.0,"3150":0.0,
            "4000":-0.5,"5000":-1.0,"6300":-1.0,"8000":-1.5,
            "10000":-2.0,"12500":-2.0,"16000":-2.5,"20000":-3.0,"25000":-3.0},
        geq_enabled=True,hpf_on=True,hpf_freq=100,lpf_on=True,lpf_freq=14000,
        comp_enabled=True,comp_thr=-14.0,comp_ratio=4.0,
        lim_enabled=True,lim_thr=-2.0,
        route_in="OBS / Streaming Software / Mic",
        route_out="Virtual Cable → Streaming Platform / Zoom / Teams",
        route_notes="Speech-forward curve. Midrange boost 250Hz–1kHz for intelligibility. Hard comp 4:1 for consistent levels. LPF 14kHz removes webcam harshness. Signal: PC Audio → NITB → Virtual Cable → OBS → Stream."),
}

PRESET_DIR  = Path(__file__).parent / "presets"
PROFILE_DIR = Path(__file__).parent / "profiles"
PRESET_DIR.mkdir(exist_ok=True)
PROFILE_DIR.mkdir(exist_ok=True)

# ── Main App ───────────────────────────────────────────────────────────────────
class NITBApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("NITB DSP CONTROL MATRIX  v0.7")
        self.geometry("1560x960")
        self.minsize(900,600)
        self.resizable(True, True)
        self.configure(fg_color=BG)
        self._mini_win = None
        _ico = Path(__file__).parent / "NITB.ico"
        if _ico.exists():
            try: self.iconbitmap(str(_ico))
            except: pass

        self.dsp       = DSPState()
        self.winvol    = MasterVolume()
        self.appsess   = AppSessions()
        self.apo       = APOWriter()
        self.analyzer  = Analyzer()
        self._devices      = []
        self._app_rows     = {}
        self._app_sessions = {}
        self._profiles     = dict(BUILTIN_PROFILES)
        self._sel_band     = 0
        self._rta_on       = True
        self._routing_win  = None
        self._knob_drag_y  = None

        self._scan_devices()
        self._load_user_profiles()
        self._build_ui()

        # Sync Windows volume
        if self.winvol.ok:
            v=self.winvol.get()
            db=lin2db(v) if v>0.001 else MASTER_MIN
            self.dsp.master_db=db; self.dsp.master_mute=self.winvol.get_mute()
            frac=(db-MASTER_MIN)/(MASTER_MAX-MASTER_MIN)
            self._master_fader.set(max(0,min(100,frac*100)))
            self._update_master_lbl()

        self.analyzer.start()
        self.apo.write(self.dsp)
        self._meter_tick()
        self._rta_tick()
        self._refresh_apps()

        # EQ keyboard bindings
        self._eq_canvas.bind("<Button-1>",self._eq_click)
        self._eq_canvas.bind("<Up>",   lambda e:self._eq_key(+GEQ_STEP))
        self._eq_canvas.bind("<Down>", lambda e:self._eq_key(-GEQ_STEP))
        self._eq_canvas.bind("<Left>", lambda e:self._sel_prev())
        self._eq_canvas.bind("<Right>",lambda e:self._sel_next())
        self.bind("<Up>",   lambda e:self._eq_key(+GEQ_STEP))
        self.bind("<Down>", lambda e:self._eq_key(-GEQ_STEP))
        self.bind("<Left>", lambda e:self._sel_prev())
        self.bind("<Right>",lambda e:self._sel_next())

        self.protocol("WM_DELETE_WINDOW",self._on_close)

    # ── Devices ───────────────────────────────────────────────────────────────
    def _scan_devices(self):
        try:
            raw=sd.query_devices()
            self._devices=[{"idx":i,"name":d["name"],
                             "in":int(d["max_input_channels"]),
                             "out":int(d["max_output_channels"])}
                            for i,d in enumerate(raw)]
        except Exception as e:
            print(f"[Devices] {e}"); self._devices=[]

    def _in_devs(self):  return [d for d in self._devices if d["in"]>0]
    def _out_devs(self): return [d for d in self._devices if d["out"]>0]

    def _load_user_profiles(self):
        for f in PROFILE_DIR.glob("*.json"):
            try:
                d=json.loads(f.read_text())
                self._profiles[d.get("preset_name",f.stem)]=d
            except: pass

    # ── UI ────────────────────────────────────────────────────────────────────
    def _build_ui(self):
        # Top bar
        top=ctk.CTkFrame(self,fg_color=PANEL,corner_radius=0,height=50)
        top.pack(fill="x"); top.pack_propagate(False)

        ctk.CTkLabel(top,text="NITB DSP CONTROL MATRIX",
                     font=("Courier New",15,"bold"),text_color=ACCENT).pack(side="left",padx=16)
        ctk.CTkLabel(top,text="v0.6  •  Naked In The Booth / 7 Virtues Entertainment",
                     font=FL,text_color=TEXTDIM).pack(side="left",padx=4)

        vc=GREEN if self.winvol.ok else WARM
        ac=GREEN if self.apo.ok   else TEXTDIM
        ctk.CTkLabel(top,text="● APO" if self.apo.ok else "○ APO",
                     font=FMS,text_color=ac).pack(side="right",padx=8)
        ctk.CTkLabel(top,text="● VOL" if self.winvol.ok else "○ VOL",
                     font=FMS,text_color=vc).pack(side="right",padx=8)
        if not self.apo.ok:
            ctk.CTkLabel(top,
                text="EQ → install Equalizer APO: equalizerapo.sourceforge.net",
                font=FMS,text_color=WARM).pack(side="right",padx=12)

        # Mini-widget pin button
        ctk.CTkButton(top,text="⊞  MINI",width=80,height=32,
                       fg_color=BORDER,hover_color=PURPLE,
                       text_color=TEXT,font=FH,
                       command=self._open_mini).pack(side="right",padx=6)

        # Make top bar draggable (move window)
        top.bind("<ButtonPress-1>",   self._drag_start)
        top.bind("<B1-Motion>",        self._drag_move)

        # Scrollable body
        self._scroll = ctk.CTkScrollableFrame(self,fg_color=BG,corner_radius=0)
        self._scroll.pack(fill="both",expand=True)

        # Bind mousewheel everywhere
        self.bind_all("<MouseWheel>",self._on_scroll)

        body=ctk.CTkFrame(self._scroll,fg_color=BG)
        body.pack(fill="both",expand=True)

        # 3 columns inside scroll
        left=ctk.CTkFrame(body,fg_color=PANEL,width=260,corner_radius=0)
        left.grid(row=0,column=0,sticky="ns")
        left.grid_propagate(False)

        center=ctk.CTkFrame(body,fg_color=BG,corner_radius=0)
        center.grid(row=0,column=1,sticky="nsew",padx=3)

        right=ctk.CTkFrame(body,fg_color=PANEL,width=300,corner_radius=0)
        right.grid(row=0,column=2,sticky="ns")
        right.grid_propagate(False)

        body.columnconfigure(1,weight=1)
        body.rowconfigure(0,weight=1)

        self._build_left(left)
        self._build_center(center)
        self._build_right(right)

    def _on_scroll(self,event):
        self._scroll._parent_canvas.yview_scroll(
            int(-1*(event.delta/120)),"units")

    # ── LEFT COLUMN ───────────────────────────────────────────────────────────
    def _build_left(self,p):
        ctk.CTkLabel(p,text="MASTER",font=FT,text_color=ACCENT
                     ).pack(pady=(14,2),padx=14,anchor="w")

        self._master_db_lbl=ctk.CTkLabel(p,text="0.0 dB",font=FB,text_color=ACCENT)
        self._master_db_lbl.pack(pady=(4,0))
        ctk.CTkLabel(p,text="MASTER OUTPUT",font=FMS,text_color=TEXTDIM).pack()

        # Fader + Gain knob side by side
        fg_row=ctk.CTkFrame(p,fg_color="transparent")
        fg_row.pack(pady=4,padx=8)

        # Scale column
        sc=ctk.CTkFrame(fg_row,fg_color="transparent")
        sc.pack(side="left",padx=(4,2))
        for lbl,col in [("+40",RED),("+12",WARM),(" +6",YELLOW),
                         ("  0",GREEN),(" -6",TEXTDIM),("-12",TEXTDIM),
                         ("-20",TEXTDIM),("-40",TEXTDIM),(" -∞",TEXTDIM)]:
            ctk.CTkLabel(sc,text=lbl,font=FMS,text_color=col).pack(anchor="e")

        # Master fader
        self._master_fader=ctk.CTkSlider(
            fg_row,from_=0,to=100,orientation="vertical",
            height=250,width=46,
            button_color=ACCENT,progress_color="#004455",
            fg_color=DIM,command=self._on_fader)
        unity_frac=(0.0-MASTER_MIN)/(MASTER_MAX-MASTER_MIN)
        self._master_fader.set(unity_frac*100)
        self._master_fader.pack(side="left")

        # Gain knob column
        knob_col=ctk.CTkFrame(fg_row,fg_color="transparent")
        knob_col.pack(side="left",padx=(8,4))

        ctk.CTkLabel(knob_col,text="GAIN",font=FMS,text_color=ACCENT).pack()

        self._gain_db_lbl=ctk.CTkLabel(
            knob_col,text="+0.0",font=("Courier New",11,"bold"),text_color=ACCENT)
        self._gain_db_lbl.pack()

        # Knob drawn on canvas
        self._knob_canvas=tk.Canvas(
            knob_col,width=72,height=72,bg=CARD,
            highlightthickness=1,highlightbackground=BORDER)
        self._knob_canvas.pack(pady=2)
        self._draw_knob(self.dsp.gain_db)

        self._knob_canvas.bind("<ButtonPress-1>",  self._knob_press)
        self._knob_canvas.bind("<B1-Motion>",       self._knob_drag)
        self._knob_canvas.bind("<ButtonRelease-1>", self._knob_release)
        self._knob_canvas.bind("<MouseWheel>",      self._knob_wheel)

        ctk.CTkLabel(knob_col,text="drag up/down\nor scroll",
                     font=FMT,text_color=TEXTDIM,justify="center").pack()

        # Reset gain button
        ctk.CTkButton(knob_col,text="Reset",width=64,height=22,
                       fg_color=BORDER,hover_color=DIM,
                       text_color=TEXT,font=FL,
                       command=self._gain_reset).pack(pady=2)

        # Mute
        self._mute_btn=ctk.CTkButton(
            p,text="MUTE",width=220,height=38,
            fg_color=BORDER,hover_color=WARM,
            text_color=TEXT,font=("Segoe UI",11,"bold"),
            command=self._on_mute)
        self._mute_btn.pack(pady=(6,4),padx=14)

        _sep(p)

        # Meters
        ctk.CTkLabel(p,text="OUTPUT LEVEL",font=FH,text_color=TEXTDIM
                     ).pack(pady=(4,2),anchor="w",padx=14)
        self._pk_bar =_mbar(p,220)
        self._rms_bar=_mbar(p,220,h=8,color="#005522")
        self._lvl_lbl=ctk.CTkLabel(p,text="-∞ / -∞  dBFS",font=FMS,text_color=TEXTDIM)
        self._lvl_lbl.pack()
        self._clip_lbl=ctk.CTkLabel(p,text="",font=("Segoe UI",10,"bold"),text_color=RED)
        self._clip_lbl.pack()

        _sep(p)

        # Profiles + presets
        ctk.CTkLabel(p,text="PROFILES & PRESETS",font=FH,text_color=ACCENT
                     ).pack(pady=(4,4),anchor="w",padx=14)

        self._profile_scroll=ctk.CTkScrollableFrame(
            p,fg_color=BG,corner_radius=6,height=180)
        self._profile_scroll.pack(fill="x",padx=14,pady=2)
        self._rebuild_profile_list()

        ctk.CTkButton(p,text="+ Add Profile",width=220,height=30,
                       fg_color=CARD,hover_color=GREEN,
                       text_color=GREEN,font=FH,
                       command=self._add_profile).pack(pady=4,padx=14)

        _sep(p)

        ctk.CTkLabel(p,text="SAVE PRESET",font=FH,text_color=ACCENT
                     ).pack(pady=(4,2),anchor="w",padx=14)
        self._preset_entry=ctk.CTkEntry(
            p,width=220,placeholder_text="Preset name...",
            fg_color=CARD,border_color=BORDER,text_color=TEXT)
        self._preset_entry.pack(pady=4,padx=14)
        pr=ctk.CTkFrame(p,fg_color="transparent")
        pr.pack(padx=14)
        ctk.CTkButton(pr,text="Save",width=106,height=28,
                       fg_color=BORDER,hover_color=GREEN,
                       text_color=TEXT,font=FL,
                       command=self._save_preset).pack(side="left",padx=2)
        ctk.CTkButton(pr,text="Browse",width=106,height=28,
                       fg_color=BORDER,hover_color=ACCENT,
                       text_color=TEXT,font=FL,
                       command=self._load_preset).pack(side="left",padx=2)
        self._preset_status=ctk.CTkLabel(p,text="",font=FMS,text_color=GREEN)
        self._preset_status.pack(pady=2)

        _sep(p)

        # ── Record section
        ctk.CTkLabel(p,text="SESSION RECORDING",font=FH,
                     text_color=ACCENT).pack(pady=(4,2),anchor="w",padx=14)
        ctk.CTkLabel(p,text="Records master output to E:\\Session Audio",
                     font=FMS,text_color=TEXTDIM,wraplength=220
                     ).pack(padx=14,anchor="w")

        self._rec_folder_lbl=ctk.CTkLabel(
            p,text="E:\\Session Audio",font=FMS,text_color=TEXTDIM)
        self._rec_folder_lbl.pack(padx=14,anchor="w",pady=2)

        self._rec_status_lbl=ctk.CTkLabel(
            p,text="● STOPPED",font=("Courier New",9,"bold"),text_color=TEXTDIM)
        self._rec_status_lbl.pack(padx=14,anchor="w")

        self._rec_time_lbl=ctk.CTkLabel(
            p,text="00:00:00",font=("Courier New",14,"bold"),text_color=TEXTDIM)
        self._rec_time_lbl.pack(padx=14,anchor="w",pady=2)

        rec_row=ctk.CTkFrame(p,fg_color="transparent")
        rec_row.pack(padx=14,pady=4)

        self._rec_btn=ctk.CTkButton(
            rec_row,text="⏺  RECORD",width=130,height=38,
            fg_color=RED,hover_color="#aa0000",
            text_color=TEXT,font=("Segoe UI",11,"bold"),
            command=self._rec_start)
        self._rec_btn.pack(side="left",padx=2)

        self._stop_btn=ctk.CTkButton(
            rec_row,text="⏹  STOP",width=80,height=38,
            fg_color=BORDER,hover_color=DIM,
            text_color=TEXTDIM,font=("Segoe UI",11,"bold"),
            state="disabled",command=self._rec_stop)
        self._stop_btn.pack(side="left",padx=2)

    def _rebuild_profile_list(self):
        for w in self._profile_scroll.winfo_children(): w.destroy()
        for name in self._profiles:
            row=ctk.CTkFrame(self._profile_scroll,fg_color="transparent")
            row.pack(fill="x",pady=1)

            is_builtin = name in BUILTIN_PROFILES
            name_color = TEXT if is_builtin else ACCENT

            ctk.CTkButton(row,text=name[:24],width=180,height=26,
                           fg_color=CARD,hover_color=BORDER,
                           text_color=name_color,font=FL,
                           command=lambda n=name:self._load_profile(n)
                           ).pack(side="left",padx=2)

            # Routing info button
            ctk.CTkButton(row,text="⇄",width=28,height=26,
                           fg_color=DIM,hover_color=PURPLE,
                           text_color=TEXTDIM,font=FL,
                           command=lambda n=name:self._show_routing(n)
                           ).pack(side="left",padx=1)

            if not is_builtin:
                ctk.CTkButton(row,text="✕",width=22,height=26,
                               fg_color="transparent",hover_color=RED,
                               text_color=TEXTDIM,font=FL,
                               command=lambda n=name:self._delete_profile(n)
                               ).pack(side="left")

    # ── Gain knob ─────────────────────────────────────────────────────────────
    def _draw_knob(self, gain_db):
        c=self._knob_canvas; c.delete("all")
        W=72; H=72; cx=W//2; cy=H//2; r=28
        # Background circle
        c.create_oval(cx-r,cy-r,cx+r,cy+r,fill=DIM,outline=BORDER,width=2)
        # Arc from -135° to +135° = 270° total range
        # gain_db 0..40 maps to 0..270 degrees from start
        frac=gain_db/GAIN_MAX
        span=frac*270
        # Start at -135° (bottom-left), draw clockwise
        c.create_arc(cx-r+3,cy-r+3,cx+r-3,cy+r-3,
                     start=225-span,extent=span,
                     style="arc",outline=ACCENT,width=3)
        # Indicator line
        angle_deg=225-frac*270
        angle_rad=math.radians(angle_deg)
        lx=cx+int((r-6)*math.cos(angle_rad))
        ly=cy-int((r-6)*math.sin(angle_rad))
        c.create_line(cx,cy,lx,ly,fill=ACCENT,width=3,capstyle="round")
        # Center dot
        c.create_oval(cx-4,cy-4,cx+4,cy+4,fill=ACCENT,outline="")

    def _knob_press(self,e):
        self._knob_drag_y=e.y

    def _knob_drag(self,e):
        if self._knob_drag_y is None: return
        delta=(self._knob_drag_y-e.y)*0.4   # pixels → dB
        self._knob_drag_y=e.y
        self._set_gain(self.dsp.gain_db+delta)

    def _knob_release(self,e):
        self._knob_drag_y=None

    def _knob_wheel(self,e):
        self._set_gain(self.dsp.gain_db + (1.0 if e.delta>0 else -1.0))

    def _set_gain(self,val):
        self.dsp.gain_db=float(np.clip(val,GAIN_MIN,GAIN_MAX))
        self._gain_db_lbl.configure(text=f"+{self.dsp.gain_db:.1f}")
        self._draw_knob(self.dsp.gain_db)
        self._update_master_lbl()
        self.apo.write(self.dsp)

    def _gain_reset(self):
        self._set_gain(0.0)

    # ── Fader ─────────────────────────────────────────────────────────────────
    def _on_fader(self,val):
        frac=float(val)/100.0
        db=MASTER_MIN+frac*(MASTER_MAX-MASTER_MIN)
        self.dsp.master_db=db
        self._update_master_lbl()
        if self.winvol.ok and not self.dsp.master_mute:
            self.winvol.set(min(1.0,db2lin(db)) if db>MASTER_MIN+1 else 0.0)
        self.apo.write(self.dsp)

    def _on_mute(self):
        self.dsp.master_mute=not self.dsp.master_mute
        m=self.dsp.master_mute
        self._mute_btn.configure(
            fg_color=WARM if m else BORDER,
            text="MUTED" if m else "MUTE",
            text_color="#000" if m else TEXT)
        self._master_db_lbl.configure(text_color=WARM if m else ACCENT)
        if self.winvol.ok: self.winvol.set_mute(m)
        self.apo.write(self.dsp)

    def _update_master_lbl(self):
        db=self.dsp.master_db; gain=self.dsp.gain_db
        total=db+gain
        if db<=MASTER_MIN+1: txt="-∞"
        else: txt=f"{total:+.1f} dB"
        col=RED if total>12 else (WARM if total>0 else ACCENT)
        self._master_db_lbl.configure(text=txt,text_color=col)

    # ── CENTER — EQ + RTA ─────────────────────────────────────────────────────
    def _build_center(self,p):
        hdr=ctk.CTkFrame(p,fg_color=PANEL,corner_radius=6)
        hdr.pack(fill="x",padx=6,pady=6)

        ctk.CTkLabel(hdr,text="32-BAND GRAPHIC EQ  +  LIVE RTA",
                     font=FT,text_color=ACCENT).pack(side="left",padx=12,pady=8)

        ctk.CTkButton(hdr,text="FLAT",width=52,height=28,
                       fg_color=BORDER,hover_color=DIM,text_color=TEXT,font=FL,
                       command=self._geq_flat).pack(side="right",padx=4)

        self._geq_on_var=ctk.BooleanVar(value=True)
        ctk.CTkSwitch(hdr,text="EQ",variable=self._geq_on_var,
                       progress_color=ACCENT,font=FL,text_color=TEXT,
                       command=self._geq_toggle).pack(side="right",padx=4)

        self._rta_on_var=ctk.BooleanVar(value=True)
        ctk.CTkSwitch(hdr,text="RTA",variable=self._rta_on_var,
                       progress_color=GREEN,font=FL,text_color=TEXT,
                       command=lambda:None).pack(side="right",padx=8)

        ctk.CTkLabel(hdr,text="Click=select  ↑↓=adjust  ←→=move band",
                     font=FMS,text_color=TEXTDIM).pack(side="right",padx=8)

        # EQ + RTA canvas (combined)
        self._eq_canvas=tk.Canvas(
            p,bg=CARD,highlightthickness=1,
            highlightbackground=BORDER,cursor="crosshair")
        self._eq_canvas.pack(fill="both",expand=True,padx=6,pady=2)
        self._eq_canvas.bind("<Configure>",lambda e:self._draw_eq_rta())

        # Filter bar
        fbar=ctk.CTkFrame(p,fg_color=PANEL,corner_radius=6)
        fbar.pack(fill="x",padx=6,pady=(2,4))

        ctk.CTkLabel(fbar,text="FILTERS",font=FH,text_color=ACCENT
                     ).pack(side="left",padx=10,pady=6)

        self._hpf_var=ctk.BooleanVar(value=False)
        ctk.CTkSwitch(fbar,text="HPF",variable=self._hpf_var,
                       progress_color=GREEN,font=FL,text_color=TEXT,
                       command=self._hpf_toggle).pack(side="left",padx=8)
        self._hpf_lbl=ctk.CTkLabel(fbar,text="80 Hz",font=FM,text_color=TEXT,width=58)
        self._hpf_lbl.pack(side="left")
        ctk.CTkSlider(fbar,from_=20,to=500,width=110,
                       button_color=GREEN,progress_color=DIM,fg_color=DIM,
                       command=self._hpf_move).pack(side="left",padx=4)

        _sep_v(fbar)

        self._lpf_var=ctk.BooleanVar(value=False)
        ctk.CTkSwitch(fbar,text="LPF",variable=self._lpf_var,
                       progress_color=WARM,font=FL,text_color=TEXT,
                       command=self._lpf_toggle).pack(side="left",padx=8)
        self._lpf_lbl=ctk.CTkLabel(fbar,text="18000 Hz",font=FM,text_color=TEXT,width=74)
        self._lpf_lbl.pack(side="left")
        ctk.CTkSlider(fbar,from_=2000,to=20000,width=110,
                       button_color=WARM,progress_color=DIM,fg_color=DIM,
                       command=self._lpf_move).pack(side="left",padx=4)

        # Spectrum analyzer canvas
        spec_hdr=ctk.CTkFrame(p,fg_color=PANEL,corner_radius=6)
        spec_hdr.pack(fill="x",padx=6,pady=(4,2))
        ctk.CTkLabel(spec_hdr,text="SPECTRUM ANALYZER",
                     font=FH,text_color=ACCENT).pack(side="left",padx=10,pady=4)
        self._rec_lbl=ctk.CTkLabel(spec_hdr,text="",font=FMS,text_color=RED)
        self._rec_lbl.pack(side="right",padx=12)
        ctk.CTkLabel(spec_hdr,
                     text="log scale  •  cyan line = live signal  •  dashed = active EQ bands",
                     font=FMS,text_color=TEXTDIM).pack(side="right",padx=8)

        self._spec_canvas=tk.Canvas(
            p,bg=BG,height=130,
            highlightthickness=1,highlightbackground=BORDER)
        self._spec_canvas.pack(fill="x",padx=6,pady=(0,6))

    # ── EQ + RTA draw ─────────────────────────────────────────────────────────
    def _draw_eq_rta(self, fft_freqs=None, fft_db=None):
        c=self._eq_canvas
        c.delete("all")
        W=c.winfo_width(); H=c.winfo_height()
        if W<10 or H<10: return

        n=len(GEQ_FREQS); bw=W/n
        mid_y=H/2; px_db=H/(GEQ_MAX*2)

        # ── Grid
        for db in [-12,-9,-6,-3,0,3,6,9,12]:
            y=mid_y-db*px_db
            c.create_line(0,y,W,y,fill="#1a1a1a" if db!=0 else "#2a2a2a",
                           dash=(3,5) if db!=0 else ())
            c.create_text(3,y-7,text=f"{db:+d}dB",
                          fill=TEXTDIM,anchor="w",font=FMT)

        # ── Live RTA overlay — draw first (behind EQ bars)
        if self._rta_on_var.get() and fft_freqs is not None and fft_db is not None:
            # Map FFT bins to x positions (log scale)
            log_min=math.log10(max(GEQ_FREQS[0],1))
            log_max=math.log10(GEQ_FREQS[-1])
            pts=[]
            for i,freq in enumerate(fft_freqs):
                if freq<20 or freq>22000: continue
                x=W*(math.log10(max(freq,1))-log_min)/(log_max-log_min)
                # Map db: -80..0 → H..0 (top of canvas = loud)
                db_val=float(fft_db[i]) if i<len(fft_db) else -80.0
                y=mid_y - db_val*(H/(GEQ_MAX*2))*0.5  # scale to half EQ height
                pts.append((x,y))

            if len(pts)>2:
                # Filled area under curve
                flat=[(pts[0][0],mid_y)] + pts + [(pts[-1][0],mid_y)]
                flat_coords=[]
                for px,py in flat: flat_coords+=[px,py]
                c.create_polygon(flat_coords,fill="#003322",outline="",stipple="gray25")
                # Line
                line_coords=[]
                for px,py in pts: line_coords+=[px,py]
                if len(line_coords)>=4:
                    c.create_line(line_coords,fill=GREEN,width=1,smooth=True)

        # ── EQ band bars
        eq_on=self._geq_on_var.get()
        for i,freq in enumerate(GEQ_FREQS):
            x0=i*bw; x1=x0+bw; xm=(x0+x1)/2
            g=self.dsp.geq_gains.get(freq,0.0)
            y0=mid_y; y1=mid_y-g*px_db
            sel=(i==self._sel_band)

            bg=SEL if sel else ("#121212" if i%2==0 else "#0f0f0f")
            c.create_rectangle(x0,0,x1,H,fill=bg,outline="")

            if abs(g)>0.05:
                col=(ACCENT if g>0 else WARM) if eq_on else TEXTDIM
                # Gradient bar
                steps=max(1,int(abs(g)*px_db))
                for s in range(steps):
                    frac_s=s/max(steps,1)
                    alpha_col=_fade(col,frac_s)
                    yy0=min(y0,y1)+s*(max(y0,y1)-min(y0,y1))/max(steps,1)
                    yy1=yy0+(max(y0,y1)-min(y0,y1))/max(steps,1)
                    c.create_rectangle(x0+2,yy0,x1-2,yy1,fill=alpha_col,outline="")

            c.create_line(x1,0,x1,H,fill=BORDER)

            ft=f"{freq}" if freq<1000 else f"{freq//1000}k"
            c.create_text(xm,H-10,text=ft,
                          fill=ACCENT if sel else TEXTDIM,
                          font=FMT,anchor="center")

            if abs(g)>0.2:
                c.create_text(xm,y1-(10 if g>0 else -12),
                               text=f"{g:+.1f}",
                               fill=TEXT,font=FMT,anchor="center")
            if sel:
                c.create_rectangle(x0+1,0,x1-1,3,fill=ACCENT,outline="")

        # Selected band info
        freq=GEQ_FREQS[self._sel_band]
        g=self.dsp.geq_gains.get(freq,0.0)
        ft=f"{freq}Hz" if freq<1000 else f"{freq//1000}kHz"
        c.create_text(W-6,10,
                      text=f"[ {ft} ]  {g:+.1f} dB  |  ↑↓ adjust  ←→ move  click to set",
                      fill=ACCENT,font=("Courier New",9),anchor="e")

    def _eq_click(self,event):
        W=self._eq_canvas.winfo_width()
        H=self._eq_canvas.winfo_height()
        if W<10: return
        n=len(GEQ_FREQS); bw=W/n
        i=int(event.x/bw); i=max(0,min(n-1,i))
        self._sel_band=i
        mid_y=H/2; px_db=H/(GEQ_MAX*2)
        g=(mid_y-event.y)/px_db
        g=round(max(-GEQ_MAX,min(GEQ_MAX,g))/GEQ_STEP)*GEQ_STEP
        self.dsp.geq_gains[GEQ_FREQS[i]]=g
        self._draw_eq_rta(); self.apo.write(self.dsp)
        self._eq_canvas.focus_set()

    def _eq_key(self,delta):
        freq=GEQ_FREQS[self._sel_band]
        g=round(max(-GEQ_MAX,min(GEQ_MAX,self.dsp.geq_gains.get(freq,0.0)+delta)),1)
        self.dsp.geq_gains[freq]=g
        self._draw_eq_rta(); self.apo.write(self.dsp)

    def _sel_prev(self):
        self._sel_band=max(0,self._sel_band-1)
        self._draw_eq_rta()

    def _sel_next(self):
        self._sel_band=min(len(GEQ_FREQS)-1,self._sel_band+1)
        self._draw_eq_rta()

    def _geq_toggle(self):
        self.dsp.geq_enabled=self._geq_on_var.get()
        self._draw_eq_rta(); self.apo.write(self.dsp)

    def _geq_flat(self):
        for f in GEQ_FREQS: self.dsp.geq_gains[f]=0.0
        self._draw_eq_rta(); self.apo.write(self.dsp)

    def _hpf_toggle(self):
        self.dsp.hpf_on=self._hpf_var.get(); self.apo.write(self.dsp)

    def _hpf_move(self,v):
        self.dsp.hpf_freq=int(float(v))
        self._hpf_lbl.configure(text=f"{self.dsp.hpf_freq} Hz")
        self.apo.write(self.dsp)

    def _lpf_toggle(self):
        self.dsp.lpf_on=self._lpf_var.get(); self.apo.write(self.dsp)

    def _lpf_move(self,v):
        self.dsp.lpf_freq=int(float(v))
        self._lpf_lbl.configure(text=f"{self.dsp.lpf_freq} Hz")
        self.apo.write(self.dsp)

    # ── RIGHT COLUMN ──────────────────────────────────────────────────────────
    def _build_right(self,p):
        ctk.CTkLabel(p,text="DYNAMICS",font=FT,text_color=ACCENT
                     ).pack(pady=(14,4),padx=14,anchor="w")

        ch=ctk.CTkFrame(p,fg_color="transparent"); ch.pack(fill="x",padx=14)
        ctk.CTkLabel(ch,text="COMPRESSOR",font=FH,text_color=TEXT).pack(side="left")
        self._comp_var=ctk.BooleanVar(value=False)
        ctk.CTkSwitch(ch,text="",variable=self._comp_var,width=44,
                       progress_color=GREEN,command=self._dyn_push).pack(side="right")

        self._dyn_row(p,"Threshold",-40, 0,-18,"dB","comp_thr")
        self._dyn_row(p,"Ratio",     1, 20,2.5,":1","comp_ratio")
        self._dyn_row(p,"Attack",    1,200, 10,"ms","comp_atk")
        self._dyn_row(p,"Release",  10,1000,150,"ms","comp_rel")
        self._dyn_row(p,"Makeup",    0, 24,  0,"dB","comp_makeup")

        _sep(p)

        lh=ctk.CTkFrame(p,fg_color="transparent"); lh.pack(fill="x",padx=14)
        ctk.CTkLabel(lh,text="LIMITER",font=FH,text_color=WARM).pack(side="left")
        self._lim_var=ctk.BooleanVar(value=True)
        ctk.CTkSwitch(lh,text="",variable=self._lim_var,width=44,
                       progress_color=WARM,command=self._dyn_push).pack(side="right")
        self._dyn_row(p,"Threshold",-20,0,-3,"dB","lim_thr")

        _sep(p)

        # App mixer
        ctk.CTkLabel(p,text="APP MIXER",font=FH,text_color=ACCENT
                     ).pack(pady=(4,2),padx=14,anchor="w")
        ctk.CTkLabel(p,text="Per-app Windows volume",font=FMS,text_color=TEXTDIM
                     ).pack(padx=14,anchor="w")
        self._app_frame=ctk.CTkScrollableFrame(
            p,fg_color=CARD,corner_radius=6,height=130)
        self._app_frame.pack(fill="x",padx=14,pady=4)

        _sep(p)

        # Meter source
        ctk.CTkLabel(p,text="METER / RTA SOURCE",font=FH,text_color=TEXTDIM
                     ).pack(pady=(4,2),padx=14,anchor="w")
        in_devs=self._in_devs()
        names=[f"{d['idx']}: {d['name'][:26]}" for d in in_devs] or ["None"]
        self._meter_var=ctk.StringVar(value=names[0])
        ctk.CTkOptionMenu(p,variable=self._meter_var,values=names,
                           fg_color=CARD,button_color=BORDER,
                           dropdown_fg_color=CARD,text_color=TEXT,width=265,
                           command=self._meter_dev_changed
                           ).pack(padx=14,pady=4)
        ctk.CTkLabel(p,
            text="Set to your Realtek recording/loopback\ndevice for live meters and RTA.",
            font=FMS,text_color=TEXTDIM,justify="left").pack(padx=14,anchor="w")

        _sep(p)

        # Output devices
        ctk.CTkLabel(p,text="OUTPUT DEVICES",font=FH,text_color=TEXTDIM
                     ).pack(pady=(4,2),padx=14,anchor="w")
        ob=ctk.CTkScrollableFrame(p,fg_color=BG,corner_radius=4,height=80)
        ob.pack(fill="x",padx=14,pady=4)
        for d in self._out_devs():
            ctk.CTkLabel(ob,text=f"▶ {d['name'][:34]}",
                          font=FMS,text_color=ACCENT,anchor="w"
                          ).pack(fill="x",padx=4,pady=1)

    def _dyn_row(self,parent,label,mn,mx,default,unit,attr):
        row=ctk.CTkFrame(parent,fg_color="transparent")
        row.pack(fill="x",padx=14,pady=2)
        ctk.CTkLabel(row,text=label,font=FL,text_color=TEXTDIM,
                      width=74,anchor="w").pack(side="left")
        vl=ctk.CTkLabel(row,text=f"{default}{unit}",font=FM,text_color=TEXT,width=58)
        vl.pack(side="right")
        def cb(v,a=attr,l=vl,u=unit):
            setattr(self.dsp,a,float(v))
            l.configure(text=f"{float(v):.1f}{u}")
            self._dyn_push()
        s=ctk.CTkSlider(row,from_=mn,to=mx,command=cb,
                         button_color=ACCENT,progress_color=DIM,
                         fg_color=DIM,height=16)
        s.set(default); s.pack(side="left",fill="x",expand=True,padx=6)

    def _dyn_push(self):
        self.dsp.comp_enabled=self._comp_var.get()
        self.dsp.lim_enabled =self._lim_var.get()
        self.apo.write(self.dsp)

    # ── App mixer ─────────────────────────────────────────────────────────────
    def _refresh_apps(self):
        for display,proc,sess in self.appsess.get():
            if proc not in self._app_sessions:
                self._app_sessions[proc]=sess
                self._add_app_row(display,proc,sess)
        self.after(3000,self._refresh_apps)

    def _add_app_row(self,display,proc,sess):
        if proc in self._app_rows: return
        row=ctk.CTkFrame(self._app_frame,fg_color="transparent")
        row.pack(fill="x",pady=2)
        ctk.CTkLabel(row,text=display[:14],font=FMS,
                      text_color=TEXT,width=90,anchor="w").pack(side="left")
        cur=self.appsess.get_vol(sess)
        vl=ctk.CTkLabel(row,text=f"{int(cur*100)}%",font=FMS,text_color=TEXTDIM,width=32)
        vl.pack(side="right")
        def slide(v,s=sess,l=vl):
            self.appsess.set_vol(s,float(v)/100.0)
            l.configure(text=f"{int(float(v))}%")
        sl=ctk.CTkSlider(row,from_=0,to=100,command=slide,
                          button_color=ACCENT,progress_color=DIM,
                          fg_color=DIM,height=14)
        sl.set(cur*100); sl.pack(side="left",fill="x",expand=True,padx=4)
        self._app_rows[proc]=sl

    # ── Routing window ────────────────────────────────────────────────────────
    def _show_routing(self, name):
        data=self._profiles.get(name,{})
        win=ctk.CTkToplevel(self)
        win.title(f"Routing — {name}")
        win.geometry("640x520")
        win.configure(fg_color=BG)
        win.grab_set()

        ctk.CTkLabel(win,text=f"SIGNAL ROUTING  —  {name.upper()}",
                     font=FT,text_color=ACCENT).pack(pady=(16,4),padx=20,anchor="w")

        # Route IN
        in_frame=ctk.CTkFrame(win,fg_color=CARD,corner_radius=8)
        in_frame.pack(fill="x",padx=20,pady=6)
        ctk.CTkLabel(in_frame,text="▶  INPUT SOURCE",
                     font=FH,text_color=GREEN).pack(anchor="w",padx=12,pady=(8,2))
        ri=data.get("route_in","System Audio")
        self._route_in_var=ctk.StringVar(value=ri)
        ctk.CTkEntry(in_frame,textvariable=self._route_in_var,
                     width=560,fg_color=DIM,border_color=BORDER,
                     text_color=TEXT,font=FM).pack(padx=12,pady=(2,8))

        # Arrow
        ctk.CTkLabel(win,text="          ↓  NITB DSP PROCESSING  ↓",
                     font=FH,text_color=ACCENT).pack(pady=2)

        # DSP chain summary
        chain=ctk.CTkFrame(win,fg_color=PANEL,corner_radius=8)
        chain.pack(fill="x",padx=20,pady=4)
        ctk.CTkLabel(chain,text="DSP CHAIN",font=FH,text_color=TEXTDIM
                     ).pack(anchor="w",padx=12,pady=(8,4))

        db=data.get("master_db",0.0); gain=data.get("gain_db",0.0)
        mute=data.get("master_mute",False)
        hpf=data.get("hpf_on",False); hpf_f=data.get("hpf_freq",80)
        lpf=data.get("lpf_on",False); lpf_f=data.get("lpf_freq",18000)
        comp=data.get("comp_enabled",False); lim=data.get("lim_enabled",False)
        geq=data.get("geq_enabled",True)
        active_bands=[(f,g) for f,g in data.get("geq_gains",{}).items() if abs(float(g))>0.05]

        chain_txt=(
            f"  Master: {db:+.1f} dB   Gain: +{gain:.1f} dB   "
            f"{'MUTED' if mute else 'Active'}\n"
            f"  HPF: {'ON @ '+str(hpf_f)+'Hz' if hpf else 'OFF'}   "
            f"LPF: {'ON @ '+str(lpf_f)+'Hz' if lpf else 'OFF'}\n"
            f"  32-Band GEQ: {'ON' if geq else 'OFF'}   "
            f"Active bands: {len(active_bands)}\n"
            f"  Compressor: {'ON' if comp else 'OFF'}   "
            f"Limiter: {'ON' if lim else 'OFF'}"
        )
        ctk.CTkLabel(chain,text=chain_txt,font=FM,text_color=TEXT,
                     justify="left").pack(anchor="w",padx=12,pady=(0,8))

        if active_bands:
            bands_str="  EQ: "+" | ".join(
                f"{f}Hz {float(g):+.0f}dB" for f,g in sorted(active_bands,key=lambda x:int(x[0]))[:8])
            if len(active_bands)>8: bands_str+=f"  +{len(active_bands)-8} more"
            ctk.CTkLabel(chain,text=bands_str,font=FMT,text_color=ACCENT,
                         justify="left").pack(anchor="w",padx=12,pady=(0,8))

        ctk.CTkLabel(win,text="          ↓  OUTPUT  ↓",
                     font=FH,text_color=WARM).pack(pady=2)

        # Route OUT
        out_frame=ctk.CTkFrame(win,fg_color=CARD,corner_radius=8)
        out_frame.pack(fill="x",padx=20,pady=6)
        ctk.CTkLabel(out_frame,text="◀  OUTPUT DESTINATION",
                     font=FH,text_color=WARM).pack(anchor="w",padx=12,pady=(8,2))
        ro=data.get("route_out","Realtek 3.5mm")
        self._route_out_var=ctk.StringVar(value=ro)
        ctk.CTkEntry(out_frame,textvariable=self._route_out_var,
                     width=560,fg_color=DIM,border_color=BORDER,
                     text_color=TEXT,font=FM).pack(padx=12,pady=(2,8))

        # Notes
        notes_frame=ctk.CTkFrame(win,fg_color=CARD,corner_radius=8)
        notes_frame.pack(fill="x",padx=20,pady=6)
        ctk.CTkLabel(notes_frame,text="NOTES",
                     font=FH,text_color=TEXTDIM).pack(anchor="w",padx=12,pady=(8,2))
        self._route_notes_var=ctk.StringVar(value=data.get("route_notes",""))
        ctk.CTkEntry(notes_frame,textvariable=self._route_notes_var,
                     width=560,fg_color=DIM,border_color=BORDER,
                     text_color=TEXT,font=FL).pack(padx=12,pady=(2,8))

        # Detected hardware
        hw_frame=ctk.CTkFrame(win,fg_color=PANEL,corner_radius=8)
        hw_frame.pack(fill="x",padx=20,pady=4)
        ctk.CTkLabel(hw_frame,text="DETECTED OUTPUTS ON THIS PC",
                     font=FH,text_color=TEXTDIM).pack(anchor="w",padx=12,pady=(8,4))
        hw_row=ctk.CTkFrame(hw_frame,fg_color="transparent")
        hw_row.pack(fill="x",padx=12,pady=(0,8))
        for d in self._out_devs()[:6]:
            ctk.CTkLabel(hw_row,text=f"▶ {d['name'][:28]}",
                          font=FMS,text_color=ACCENT).pack(side="left",padx=8)

        # Save routing edits
        def save_routing():
            self._profiles[name]["route_in"]    = self._route_in_var.get()
            self._profiles[name]["route_out"]   = self._route_out_var.get()
            self._profiles[name]["route_notes"] = self._route_notes_var.get()
            if name not in BUILTIN_PROFILES:
                (PROFILE_DIR/f"{name}.json").write_text(
                    json.dumps(self._profiles[name],indent=2))
            win.destroy()

        btn_row=ctk.CTkFrame(win,fg_color="transparent")
        btn_row.pack(pady=8)
        ctk.CTkButton(btn_row,text="Save Routing",width=140,height=32,
                       fg_color=GREEN,hover_color="#006622",
                       text_color="#000",font=FH,
                       command=save_routing).pack(side="left",padx=6)
        ctk.CTkButton(btn_row,text="Close",width=100,height=32,
                       fg_color=BORDER,hover_color=DIM,
                       text_color=TEXT,font=FL,
                       command=win.destroy).pack(side="left",padx=6)

    # ── Profile / Preset ──────────────────────────────────────────────────────
    def _load_profile(self,name):
        data=self._profiles.get(name)
        if not data: return
        self.dsp.from_dict(data)
        self._sync_ui()
        self.apo.write(self.dsp)
        if self.winvol.ok:
            sc=min(1.0,db2lin(self.dsp.master_db)) if self.dsp.master_db>MASTER_MIN+1 else 0.0
            self.winvol.set(sc); self.winvol.set_mute(self.dsp.master_mute)
        # Auto-show routing
        self._show_routing(name)

    def _add_profile(self):
        name=simpledialog.askstring("Add Profile","Profile name:",parent=self)
        if not name or not name.strip(): return
        name=name.strip()

        # Ask for routing info
        route_in=simpledialog.askstring(
            "Input Source",
            "What is the input source for this profile?\n"
            "(e.g. Rekordbox, System Audio, Mic Input)",
            parent=self) or "System Audio"
        route_out=simpledialog.askstring(
            "Output Destination",
            "Where is this profile sending audio?\n"
            "(e.g. Realtek 3.5mm → Crown → PA, USB Interface → M32)",
            parent=self) or "Realtek 3.5mm"

        self.dsp.preset_name=name
        self.dsp.route_in=route_in
        self.dsp.route_out=route_out
        data=self.dsp.to_dict()
        self._profiles[name]=data
        self._save_user_profile(name,data)
        self._rebuild_profile_list()
        self._preset_status.configure(text=f"✓ Profile '{name}' saved",text_color=GREEN)

    def _save_user_profile(self,name,data):
        (PROFILE_DIR/f"{name}.json").write_text(json.dumps(data,indent=2))

    def _delete_profile(self,name):
        self._profiles.pop(name,None)
        p=PROFILE_DIR/f"{name}.json"
        if p.exists(): p.unlink()
        self._rebuild_profile_list()

    def _save_preset(self):
        name=self._preset_entry.get().strip()
        if not name:
            self._preset_status.configure(text="Enter a name.",text_color=WARM); return
        self.dsp.preset_name=name
        (PRESET_DIR/f"{name}.json").write_text(json.dumps(self.dsp.to_dict(),indent=2))
        self._preset_status.configure(text=f"✓ Saved: {name}",text_color=GREEN)

    def _load_preset(self):
        path=filedialog.askopenfilename(
            initialdir=str(PRESET_DIR),title="Load Preset",
            filetypes=[("NITB Preset","*.json")])
        if not path: return
        try:
            self.dsp.from_dict(json.loads(open(path).read()))
            self._sync_ui(); self.apo.write(self.dsp)
            if self.winvol.ok:
                self.winvol.set(min(1.0,db2lin(self.dsp.master_db)))
            self._preset_status.configure(text=f"✓ {self.dsp.preset_name}",text_color=ACCENT)
        except Exception as e:
            self._preset_status.configure(text=f"Error: {e}",text_color=RED)

    def _sync_ui(self):
        db=self.dsp.master_db
        frac=(db-MASTER_MIN)/(MASTER_MAX-MASTER_MIN)
        self._master_fader.set(max(0,min(100,frac*100)))
        self._draw_knob(self.dsp.gain_db)
        self._gain_db_lbl.configure(text=f"+{self.dsp.gain_db:.1f}")
        self._update_master_lbl()
        m=self.dsp.master_mute
        self._mute_btn.configure(
            fg_color=WARM if m else BORDER,
            text="MUTED" if m else "MUTE",
            text_color="#000" if m else TEXT)
        self._master_db_lbl.configure(text_color=WARM if m else ACCENT)
        self._geq_on_var.set(self.dsp.geq_enabled)
        self._draw_eq_rta()
        self._hpf_var.set(self.dsp.hpf_on)
        self._hpf_lbl.configure(text=f"{self.dsp.hpf_freq} Hz")
        self._lpf_var.set(self.dsp.lpf_on)
        self._lpf_lbl.configure(text=f"{self.dsp.lpf_freq} Hz")
        self._comp_var.set(self.dsp.comp_enabled)
        self._lim_var.set(self.dsp.lim_enabled)

    # ── Meter / RTA ticks ─────────────────────────────────────────────────────
    def _meter_dev_changed(self,val):
        try: self.analyzer.start(int(val.split(":")[0]))
        except Exception as e: print(f"[Meter] {e}")

    def _meter_tick(self):
        pk,rms,clip,_,_=self.analyzer.read()
        pn=norm(pk); rn=norm(rms)
        pc=RED if clip else (WARM if pk>-6 else (ACCENT if pk>-18 else GREEN))
        self._pk_bar.set(pn); self._pk_bar.configure(progress_color=pc)
        self._rms_bar.set(rn)
        txt=f"{pk:.1f} / {rms:.1f}  dBFS" if pk>-119 else "-∞ / -∞  dBFS"
        self._lvl_lbl.configure(text=txt,
            text_color=RED if clip else (TEXT if pk>-119 else TEXTDIM))
        self._clip_lbl.configure(text="▲ CLIP" if clip else "")
        self.after(80,self._meter_tick)

    def _rta_tick(self):
        pk,rms,clip,freqs,fft_db=self.analyzer.read()
        # Always pass live data — draw_eq_rta decides whether to paint the overlay
        self._draw_eq_rta(freqs if self._rta_on_var.get() else None,
                          fft_db if self._rta_on_var.get() else None)
        # Spectral analyzer
        self._draw_spectrum(freqs, fft_db)
        self.after(33,self._rta_tick)

    # ── Spectral Analyzer ─────────────────────────────────────────────────────
    def _draw_spectrum(self, freqs, fft_db):
        c = self._spec_canvas
        c.delete("all")
        W = c.winfo_width(); H = c.winfo_height()
        if W < 10 or H < 10 or freqs is None or fft_db is None: return

        FLOOR = -80.0; CEIL = 0.0; db_range = CEIL - FLOOR
        PAD_L = 42; PAD_R = 10; PAD_T = 6; PAD_B = 22
        PW = W - PAD_L - PAD_R; PH = H - PAD_T - PAD_B

        # Grid
        for db in [0, -12, -24, -36, -48, -60, -72]:
            y = PAD_T + PH * (1 - (db - FLOOR) / db_range)
            c.create_line(PAD_L, y, W-PAD_R, y, fill="#1a1a1a", dash=(2,4))
            c.create_text(PAD_L-4, y, text=f"{db:d}", fill="#404040",
                          font=("Courier New",7), anchor="e")

        # Frequency grid lines + labels
        freq_marks = [20,50,100,200,500,1000,2000,5000,10000,20000]
        log_min = math.log10(20); log_max = math.log10(20000)
        for fm in freq_marks:
            if fm < 20 or fm > 20000: continue
            x = PAD_L + PW*(math.log10(fm)-log_min)/(log_max-log_min)
            c.create_line(x, PAD_T, x, PAD_T+PH, fill="#1a1a1a", dash=(2,4))
            lbl = f"{fm//1000}k" if fm>=1000 else str(fm)
            c.create_text(x, PAD_T+PH+12, text=lbl, fill="#404040",
                          font=("Courier New",7), anchor="center")

        # Build spectrum polyline (log x scale)
        pts = []
        for i, freq in enumerate(freqs):
            if freq < 20 or freq > 20000: continue
            x = PAD_L + PW*(math.log10(max(freq,1))-log_min)/(log_max-log_min)
            db_val = float(fft_db[i]) if i < len(fft_db) else FLOOR
            db_val = max(FLOOR, min(CEIL, db_val))
            y = PAD_T + PH*(1-(db_val-FLOOR)/db_range)
            pts.append((x,y))

        if len(pts) > 2:
            # Filled area
            fill_pts = [(PAD_L, PAD_T+PH)] + pts + [(pts[-1][0], PAD_T+PH)]
            flat = []
            for px,py in fill_pts: flat += [px,py]
            c.create_polygon(flat, fill="#001a22", outline="")
            # Line
            line_flat = []
            for px,py in pts: line_flat += [px,py]
            if len(line_flat) >= 4:
                c.create_line(line_flat, fill="#00e5ff", width=1.5, smooth=True)

        # EQ band gain overlays on spectrum
        if self.dsp.geq_enabled:
            for freq in GEQ_FREQS:
                g = self.dsp.geq_gains.get(freq, 0.0)
                if abs(g) < 0.1: continue
                if freq < 20 or freq > 20000: continue
                x = PAD_L + PW*(math.log10(max(freq,1))-log_min)/(log_max-log_min)
                col = "#00e5ff" if g > 0 else "#ff6b00"
                c.create_line(x, PAD_T, x, PAD_T+PH, fill=col,
                              width=2, dash=(4,3))
                c.create_text(x, PAD_T+4, text=f"{g:+.0f}",
                              fill=col, font=("Courier New",7), anchor="center")

        # Border
        c.create_rectangle(PAD_L, PAD_T, W-PAD_R, PAD_T+PH,
                           outline="#252525", fill="")

        # Label
        c.create_text(PAD_L+4, PAD_T+8, text="SPECTRUM ANALYZER — MASTER SEND",
                      fill="#00e5ff", font=("Courier New",8,"bold"), anchor="w")

    # ── Recording engine ──────────────────────────────────────────────────────
    def _rec_start(self):
        import wave, datetime
        if getattr(self,"_rec_active",False): return

        # Resolve output folder — E:\Session Audio, fallback to Desktop
        folders=[
            r"E:\Session Audio",
            r"E:\session audio",
            os.path.join(os.path.expanduser("~"),"Desktop","Session Audio"),
        ]
        folder=None
        for f in folders:
            try:
                os.makedirs(f,exist_ok=True)
                folder=f; break
            except: pass
        if not folder:
            messagebox.showerror("NITB Record",
                "Could not access E:\\Session Audio\nPlug in Drive E and try again.")
            return

        self._rec_folder=folder
        ts=datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        self._rec_path=os.path.join(folder,f"NITB_{ts}.wav")

        # Get input device from meter selector
        try:
            dev_idx=int(self._meter_var.get().split(":")[0])
        except:
            dev_idx=None

        self._rec_frames=[]
        self._rec_active=True
        self._rec_start_time=__import__("time").time()
        self._rec_device_idx=dev_idx

        def rec_cb(indata,frames,t,status):
            if self._rec_active:
                self._rec_frames.append(indata.copy())

        try:
            kw=dict(channels=1,samplerate=SR,dtype="int16",callback=rec_cb)
            if dev_idx is not None: kw["device"]=dev_idx
            self._rec_stream=sd.InputStream(**kw)
            self._rec_stream.start()
        except Exception as e:
            self._rec_active=False
            messagebox.showerror("NITB Record",f"Could not open audio device:\n{e}")
            return

        # Update UI
        self._rec_btn.configure(state="disabled",fg_color="#660000")
        self._stop_btn.configure(state="normal",fg_color=BORDER,text_color=TEXT)
        self._rec_status_lbl.configure(text="● RECORDING",text_color=RED)
        self._rec_folder_lbl.configure(text=os.path.basename(self._rec_path))
        try: self._rec_lbl.configure(text="⏺ REC")
        except: pass
        self._rec_tick()

    def _rec_tick(self):
        if not getattr(self,"_rec_active",False): return
        elapsed=int(__import__("time").time()-self._rec_start_time)
        h=elapsed//3600; m=(elapsed%3600)//60; s=elapsed%60
        txt=f"{h:02d}:{m:02d}:{s:02d}"
        self._rec_time_lbl.configure(text=txt,text_color=RED)
        self.after(500,self._rec_tick)

    def _rec_stop(self):
        if not getattr(self,"_rec_active",False): return
        self._rec_active=False

        # Stop stream
        try:
            self._rec_stream.stop()
            self._rec_stream.close()
        except: pass

        # Write WAV
        import wave, numpy as _np
        if self._rec_frames:
            data=_np.concatenate(self._rec_frames,axis=0)
            try:
                with wave.open(self._rec_path,"wb") as wf:
                    wf.setnchannels(1)
                    wf.setsampwidth(2)   # int16 = 2 bytes
                    wf.setframerate(SR)
                    wf.writeframes(data.tobytes())
                size_mb=os.path.getsize(self._rec_path)/1e6
                self._rec_status_lbl.configure(
                    text=f"✓ SAVED  {size_mb:.1f} MB",text_color=GREEN)
                self._rec_folder_lbl.configure(
                    text=self._rec_path,text_color=GREEN)
                # Update mini-widget if open
                try: self._mini_rec_lbl.configure(text="")
                except: pass
            except Exception as e:
                self._rec_status_lbl.configure(text=f"ERROR: {e}",text_color=RED)
        else:
            self._rec_status_lbl.configure(text="Nothing recorded",text_color=WARM)

        self._rec_time_lbl.configure(text_color=TEXTDIM)
        self._rec_btn.configure(state="normal",fg_color=RED)
        self._stop_btn.configure(state="disabled",text_color=TEXTDIM)
        try: self._rec_lbl.configure(text="")
        except: pass

    # ── Window drag (top bar) ──────────────────────────────────────────────────
    def _drag_start(self,event):
        self._drag_x=event.x_root-self.winfo_x()
        self._drag_y=event.y_root-self.winfo_y()

    def _drag_move(self,event):
        self.geometry(f"+{event.x_root-self._drag_x}+{event.y_root-self._drag_y}")

    # ── Mini-widget ───────────────────────────────────────────────────────────
    def _open_mini(self):
        if self._mini_win and self._mini_win.winfo_exists():
            self._mini_win.lift(); return

        mw=tk.Toplevel(self)
        mw.title("NITB Mini")
        mw.geometry("340x310+40+40")
        mw.resizable(False,False)
        mw.configure(bg=BG)
        mw.attributes("-topmost",True)
        mw.overrideredirect(True)   # borderless — always on top
        self._mini_win=mw

        # ICO
        _ico=Path(__file__).parent/"NITB.ico"
        if _ico.exists():
            try: mw.iconbitmap(str(_ico))
            except: pass

        # Drag support for mini
        def mini_drag_start(e): mw._dx=e.x_root-mw.winfo_x(); mw._dy=e.y_root-mw.winfo_y()
        def mini_drag_move(e):  mw.geometry(f"+{e.x_root-mw._dx}+{e.y_root-mw._dy}")

        # ── Mini top bar
        mtop=tk.Frame(mw,bg=PANEL,height=32)
        mtop.pack(fill="x")
        mtop.pack_propagate(False)
        mtop.bind("<ButtonPress-1>", mini_drag_start)
        mtop.bind("<B1-Motion>",     mini_drag_move)

        tk.Label(mtop,text="NITB DSP  —  MINI",
                 bg=PANEL,fg=ACCENT,
                 font=("Courier New",9,"bold")).pack(side="left",padx=8,pady=6)

        tk.Button(mtop,text="✕",bg=PANEL,fg=TEXTDIM,
                  relief="flat",bd=0,
                  font=("Courier New",10),
                  command=mw.destroy).pack(side="right",padx=8)

        tk.Button(mtop,text="↗",bg=PANEL,fg=TEXTDIM,
                  relief="flat",bd=0,
                  font=("Courier New",10),
                  command=lambda:(mw.destroy(),self.deiconify(),self.lift())
                  ).pack(side="right",padx=4)

        # ── Master volume display
        tk.Label(mw,text="MASTER",bg=BG,fg=TEXTDIM,
                 font=("Courier New",8)).pack(pady=(8,0))
        self._mini_db_lbl=tk.Label(mw,text="0.0 dB",bg=BG,fg=ACCENT,
                                    font=("Courier New",18,"bold"))
        self._mini_db_lbl.pack()

        # Volume slider (horizontal)
        frac_now=(self.dsp.master_db-MASTER_MIN)/(MASTER_MAX-MASTER_MIN)
        self._mini_fader_var=tk.DoubleVar(value=frac_now*100)
        def mini_fader(v):
            self._master_fader.set(float(v))
            self._on_fader(float(v))
            self._mini_db_lbl.configure(text=self._master_db_lbl.cget("text"))
        tk.Scale(mw,variable=self._mini_fader_var,
                 from_=0,to=100,orient="horizontal",length=300,
                 bg=BG,fg=ACCENT,troughcolor=DIM,
                 highlightthickness=0,bd=0,showvalue=False,
                 command=mini_fader).pack(padx=16,pady=4)

        # Mute
        self._mini_mute_var=tk.BooleanVar(value=self.dsp.master_mute)
        def mini_mute():
            self._on_mute()
            self._mini_mute_var.set(self.dsp.master_mute)
            mini_mute_btn.configure(
                bg=WARM if self.dsp.master_mute else BORDER,
                fg="#000" if self.dsp.master_mute else TEXT)
        mini_mute_btn=tk.Button(mw,text="MUTE",bg=BORDER,fg=TEXT,
                                 font=("Segoe UI",11,"bold"),
                                 relief="flat",bd=0,width=10,pady=6,
                                 command=mini_mute)
        mini_mute_btn.pack(pady=4)

        # Profile quick-load buttons
        tk.Label(mw,text="PROFILES",bg=BG,fg=TEXTDIM,
                 font=("Courier New",8)).pack(pady=(6,2))
        pg=tk.Frame(mw,bg=BG)
        pg.pack()
        for i,(name,_) in enumerate(list(self._profiles.items())[:6]):
            short=name[:12]
            btn=tk.Button(pg,text=short,width=10,
                          bg=CARD,fg=TEXT,relief="flat",bd=1,
                          font=("Segoe UI",8),
                          command=lambda n=name:(self._load_profile(n),
                                                 self._mini_db_lbl.configure(
                                                     text=self._master_db_lbl.cget("text"))))
            btn.grid(row=i//3,column=i%3,padx=2,pady=2)

        # Record / Stop
        rec_row=tk.Frame(mw,bg=BG)
        rec_row.pack(pady=(8,4))
        tk.Button(rec_row,text="⏺  REC",bg=RED,fg=TEXT,
                  font=("Segoe UI",10,"bold"),relief="flat",bd=0,
                  padx=10,pady=6,
                  command=self._rec_start).pack(side="left",padx=4)
        tk.Button(rec_row,text="⏹  STOP",bg=BORDER,fg=TEXT,
                  font=("Segoe UI",10,"bold"),relief="flat",bd=0,
                  padx=10,pady=6,
                  command=self._rec_stop).pack(side="left",padx=4)
        self._mini_rec_lbl=tk.Label(rec_row,text="",bg=BG,fg=RED,
                                     font=("Courier New",9,"bold"))
        self._mini_rec_lbl.pack(side="left",padx=6)

        # Keep mini volume in sync via poll
        def _sync_mini():
            if not mw.winfo_exists(): return
            self._mini_db_lbl.configure(text=self._master_db_lbl.cget("text"))
            frac=(self.dsp.master_db-MASTER_MIN)/(MASTER_MAX-MASTER_MIN)
            self._mini_fader_var.set(max(0,min(100,frac*100)))
            if getattr(self,"_rec_active",False):
                self._mini_rec_lbl.configure(text="⏺ REC")
            mw.after(200,_sync_mini)
        _sync_mini()

    def _on_close(self):
        self._rec_stop() if getattr(self,"_rec_active",False) else None
        self.analyzer.stop(); self.destroy()

# ── Helpers ────────────────────────────────────────────────────────────────────
def _sep(p):
    ctk.CTkFrame(p,fg_color=BORDER,height=1,corner_radius=0
                  ).pack(fill="x",padx=10,pady=6)

def _sep_v(p):
    ctk.CTkFrame(p,fg_color=BORDER,width=1,corner_radius=0
                  ).pack(side="left",fill="y",padx=6,pady=4)

def _mbar(p,w=220,h=16,color=GREEN):
    b=ctk.CTkProgressBar(p,width=w,height=h,progress_color=color,
                          fg_color=BORDER,corner_radius=3)
    b.set(0); b.pack(padx=14,pady=2); return b

def _fade(hex_color, frac):
    """Darken a hex color by frac (0=full, 1=black)."""
    h=hex_color.lstrip("#")
    r,g,b=int(h[0:2],16),int(h[2:4],16),int(h[4:6],16)
    f=1.0-frac*0.6
    return f"#{int(r*f):02x}{int(g*f):02x}{int(b*f):02x}"

# ── Entry ──────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    app = NITBApp()
    app.mainloop()
