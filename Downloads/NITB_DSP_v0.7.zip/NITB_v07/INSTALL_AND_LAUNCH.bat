@echo off
title NITB DSP Control Matrix v0.7

echo.
echo ================================================================
echo   NITB DSP CONTROL MATRIX  v0.7
echo   Naked In The Booth / 7 Virtues Entertainment
echo ================================================================
echo.

python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python not found.
    echo Install from https://www.python.org/downloads/
    echo Check "Add Python to PATH" during install.
    pause & exit /b 1
)
echo [OK] Python found.
echo.
echo Installing packages...
python -m pip install --upgrade pip --quiet
python -m pip install numpy scipy sounddevice customtkinter pycaw comtypes --quiet
if errorlevel 1 ( echo [ERROR] Install failed. Try as Administrator. & pause & exit /b 1 )
echo [OK] All packages ready.
echo.

:: Check APO
if exist "C:\Program Files\EqualizerAPO\config"       echo [OK] Equalizer APO detected -- EQ live.
if exist "C:\Program Files (x86)\EqualizerAPO\config" echo [OK] Equalizer APO detected -- EQ live.
if not exist "C:\Program Files\EqualizerAPO\config" if not exist "C:\Program Files (x86)\EqualizerAPO\config" (
    echo [!] Equalizer APO not found.
    echo     Master fader, gain knob, app mixer and recording still work.
    echo     For system EQ: equalizerapo.sourceforge.net
    echo     Select Realtek during APO install. App auto-links on next launch.
)

:: Check E: drive for session recording
if exist "E:\" (
    if not exist "E:\Session Audio" mkdir "E:\Session Audio"
    echo [OK] E:\Session Audio ready for recordings.
) else (
    echo [!] Drive E: not found.
    echo     Recordings will save to Desktop\Session Audio when E: is unavailable.
)

echo.
echo ================================================================
echo   Launching NITB DSP Control Matrix v0.7...
echo ================================================================
echo.
python "%~dp0NITB_DSP_Matrix.py"
if errorlevel 1 ( echo. & echo [ERROR] See above. & pause )
