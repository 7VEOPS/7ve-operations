@echo off
python "%~dp0NITB_DSP_Matrix.py"
if errorlevel 1 pause
