// ============================================================
// ART-NET UDP SENDER
// Sends DMX universes to the Art-Net node (your WiFi dongle)
// Art-Net uses UDP port 6454, broadcast or unicast
// ============================================================

const dgram = require('dgram');

const ARTNET_PORT = 6454;
const ARTNET_HEADER = Buffer.from([
  0x41, 0x72, 0x74, 0x2d, 0x4e, 0x65, 0x74, 0x00, // "Art-Net\0"
  0x00, 0x50,  // OpCode ArtDMX = 0x5000 (little-endian)
  0x00, 0x0e,  // Protocol version 14 (big-endian)
  0x00,        // Sequence (0 = disabled)
  0x00,        // Physical port
]);

class ArtNetSender {
  constructor(targetIp = '2.255.255.255') {
    // Default: broadcast on 2.x.x.x subnet (Art-Net standard)
    // Change to your dongle's specific IP for unicast
    this.targetIp = targetIp;
    this.socket = dgram.createSocket({ type: 'udp4', reuseAddr: true });
    this.socket.bind(() => {
      try { this.socket.setBroadcast(true); } catch(e) {}
    });
    this.socket.on('error', (err) => {
      console.error('[ArtNet] UDP error:', err.message);
    });
    console.log(`[ArtNet] Sender initialized → ${targetIp}:${ARTNET_PORT}`);
  }

  // Send one universe of DMX data
  // universe: 0-indexed (0 = Universe 1, 1 = Universe 2)
  // data: Buffer or Uint8Array of 512 bytes
  sendUniverse(universe, data) {
    const dmxData = Buffer.alloc(512);
    if (data) {
      const src = Buffer.isBuffer(data) ? data : Buffer.from(data);
      src.copy(dmxData, 0, 0, Math.min(src.length, 512));
    }

    // Art-Net universe addressing: SubUni byte, Net byte
    const subUni = universe & 0xFF;
    const net    = (universe >> 8) & 0x7F;

    const packet = Buffer.alloc(18 + 512);
    ARTNET_HEADER.copy(packet, 0);
    packet[14] = subUni;   // SubUni
    packet[15] = net;      // Net
    packet[16] = 0x02;     // Length MSB (512 = 0x0200)
    packet[17] = 0x00;     // Length LSB
    dmxData.copy(packet, 18);

    this.socket.send(packet, 0, packet.length, ARTNET_PORT, this.targetIp, (err) => {
      if (err) console.error('[ArtNet] Send error:', err.message);
    });
  }

  setTarget(ip) {
    this.targetIp = ip;
    console.log(`[ArtNet] Target updated → ${ip}`);
  }

  close() {
    this.socket.close();
  }
}

module.exports = ArtNetSender;
