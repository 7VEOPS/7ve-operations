// ============================================================
// DMX CONTROLLER SERVER
// Express HTTP + WebSocket (ws) for real-time control
// ============================================================

const express     = require('express');
const http        = require('http');
const WebSocket   = require('ws');
const path        = require('path');
const fs          = require('fs');

const ArtNetSender  = require('./artnet');
const DmxEngine     = require('./engine');
const { FIXTURE_TYPES, PATCH, DEFAULT_GROUPS } = require('./fixtures');

const PORT         = 3000;
const SCENES_FILE  = path.join(__dirname, '../data/scenes.json');
const CONFIG_FILE  = path.join(__dirname, '../data/config.json');

// ── Ensure data dir ──────────────────────────────────────────
fs.mkdirSync(path.dirname(SCENES_FILE), { recursive: true });

// ── Load persisted config ────────────────────────────────────
let config = { artnetIp: '2.255.255.255' };
if (fs.existsSync(CONFIG_FILE)) {
  try { config = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8')); } catch(e) {}
}

// ── Load persisted scenes ────────────────────────────────────
let scenes = [];
if (fs.existsSync(SCENES_FILE)) {
  try { scenes = JSON.parse(fs.readFileSync(SCENES_FILE, 'utf8')); } catch(e) {}
}

// ── Groups (in-memory, can be customized) ─────────────────────
let groups = [...DEFAULT_GROUPS];

// ── Boot Art-Net + Engine ─────────────────────────────────────
const artnet = new ArtNetSender(config.artnetIp);
const engine = new DmxEngine(artnet);
engine.start();

// ── Express app ───────────────────────────────────────────────
const app    = express();
const server = http.createServer(app);
const wss    = new WebSocket.Server({ server });

app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));

// ── Broadcast to all WebSocket clients ───────────────────────
function broadcast(msg) {
  const str = JSON.stringify(msg);
  wss.clients.forEach(c => { if (c.readyState === WebSocket.OPEN) c.send(str); });
}

// ── REST API ──────────────────────────────────────────────────

// GET patch + fixture types + groups
app.get('/api/patch', (req, res) => {
  res.json({ patch: PATCH, fixtureTypes: FIXTURE_TYPES, groups, config });
});

// GET full DMX state
app.get('/api/state', (req, res) => {
  res.json(engine.getSnapshot());
});

// POST set single channel
app.post('/api/channel', (req, res) => {
  const { fixtureId, channel, value } = req.body;
  const ok = engine.setChannel(fixtureId, channel, value);
  if (!ok) return res.status(404).json({ error: 'Fixture not found' });
  broadcast({ type: 'channel', fixtureId, channel, value });
  res.json({ ok: true });
});

// POST set all channels for a fixture
app.post('/api/fixture', (req, res) => {
  const { fixtureId, values } = req.body;
  const ok = engine.setFixture(fixtureId, values);
  if (!ok) return res.status(404).json({ error: 'Fixture not found' });
  broadcast({ type: 'fixture', fixtureId, values });
  res.json({ ok: true });
});

// POST set channel type for a fixture (e.g. dimmer, red, pan…)
app.post('/api/fixture/type', (req, res) => {
  const { fixtureId, channelType, value } = req.body;
  const ok = engine.setFixtureByType(fixtureId, channelType, value);
  if (!ok) return res.status(404).json({ error: 'Fixture not found' });
  broadcast({ type: 'fixtureType', fixtureId, channelType, value });
  res.json({ ok: true });
});

// POST set channel type for a GROUP of fixtures
app.post('/api/group', (req, res) => {
  const { groupId, channelType, value, values } = req.body;
  const group = groups.find(g => g.id === groupId);
  if (!group) return res.status(404).json({ error: 'Group not found' });

  group.fixtureIds.forEach(fid => {
    if (channelType) {
      engine.setFixtureByType(fid, channelType, value);
    }
    if (values) {
      engine.setFixture(fid, values);
    }
  });
  broadcast({ type: 'group', groupId, channelType, value, values });
  res.json({ ok: true });
});

// POST master dimmer
app.post('/api/master', (req, res) => {
  const { value } = req.body;
  engine.setMaster(value / 255);
  broadcast({ type: 'master', value });
  res.json({ ok: true });
});

// POST blackout
app.post('/api/blackout', (req, res) => {
  const { active } = req.body;
  engine.setBlackout(active);
  broadcast({ type: 'blackout', active });
  res.json({ ok: true });
});

// ── Scene Management ──────────────────────────────────────────

// GET all scenes
app.get('/api/scenes', (req, res) => res.json(scenes));

// POST save scene
app.post('/api/scenes', (req, res) => {
  const { name, id } = req.body;
  const sceneId = id || `scene_${Date.now()}`;
  const snap = engine.getSnapshot();
  const existing = scenes.findIndex(s => s.id === sceneId);
  const scene = { id: sceneId, name: name || 'Untitled', snapshot: snap, updatedAt: Date.now() };
  if (existing >= 0) scenes[existing] = scene;
  else scenes.push(scene);
  fs.writeFileSync(SCENES_FILE, JSON.stringify(scenes, null, 2));
  broadcast({ type: 'sceneSaved', scene: { id: scene.id, name: scene.name, updatedAt: scene.updatedAt } });
  res.json({ ok: true, scene });
});

// POST recall scene
app.post('/api/scenes/:id/recall', (req, res) => {
  const scene = scenes.find(s => s.id === req.params.id);
  if (!scene) return res.status(404).json({ error: 'Scene not found' });
  engine.restoreSnapshot(scene.snapshot);
  broadcast({ type: 'sceneRecalled', sceneId: scene.id, snapshot: scene.snapshot });
  res.json({ ok: true });
});

// DELETE scene
app.delete('/api/scenes/:id', (req, res) => {
  scenes = scenes.filter(s => s.id !== req.params.id);
  fs.writeFileSync(SCENES_FILE, JSON.stringify(scenes, null, 2));
  broadcast({ type: 'sceneDeleted', sceneId: req.params.id });
  res.json({ ok: true });
});

// ── Config ────────────────────────────────────────────────────
app.post('/api/config', (req, res) => {
  const { artnetIp } = req.body;
  if (artnetIp) {
    config.artnetIp = artnetIp;
    artnet.setTarget(artnetIp);
  }
  fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2));
  res.json({ ok: true, config });
});

// ── WebSocket (low-latency fader updates) ────────────────────
wss.on('connection', (ws, req) => {
  const ip = req.socket.remoteAddress;
  console.log(`[WS] Client connected: ${ip}`);

  // Send current state on connect
  ws.send(JSON.stringify({ type: 'init', ...engine.getSnapshot(), patch: PATCH, fixtureTypes: FIXTURE_TYPES, groups, config }));

  ws.on('message', (raw) => {
    let msg;
    try { msg = JSON.parse(raw); } catch(e) { return; }

    switch (msg.type) {
      case 'channel':
        engine.setChannel(msg.fixtureId, msg.channel, msg.value);
        broadcast({ type: 'channel', fixtureId: msg.fixtureId, channel: msg.channel, value: msg.value });
        break;
      case 'fixture':
        engine.setFixture(msg.fixtureId, msg.values);
        broadcast({ type: 'fixture', fixtureId: msg.fixtureId, values: msg.values });
        break;
      case 'fixtureType':
        engine.setFixtureByType(msg.fixtureId, msg.channelType, msg.value);
        broadcast({ type: 'fixtureType', fixtureId: msg.fixtureId, channelType: msg.channelType, value: msg.value });
        break;
      case 'group':
        const group = groups.find(g => g.id === msg.groupId);
        if (group) {
          group.fixtureIds.forEach(fid => {
            if (msg.channelType) engine.setFixtureByType(fid, msg.channelType, msg.value);
            if (msg.values) engine.setFixture(fid, msg.values);
          });
          broadcast(msg);
        }
        break;
      case 'master':
        engine.setMaster(msg.value / 255);
        broadcast(msg);
        break;
      case 'blackout':
        engine.setBlackout(msg.active);
        broadcast(msg);
        break;
    }
  });

  ws.on('close', () => console.log(`[WS] Client disconnected: ${ip}`));
  ws.on('error', (e) => console.error(`[WS] Error: ${e.message}`));
});

// ── Start ─────────────────────────────────────────────────────
server.listen(PORT, '0.0.0.0', () => {
  console.log(`\n╔══════════════════════════════════════╗`);
  console.log(`║   DMX CONTROLLER SERVER              ║`);
  console.log(`║   http://localhost:${PORT}               ║`);
  console.log(`║   Art-Net → ${config.artnetIp.padEnd(20)}║`);
  console.log(`╚══════════════════════════════════════╝\n`);
  const os = require('os');
  const interfaces = os.networkInterfaces();
  Object.values(interfaces).flat().filter(i => i.family === 'IPv4' && !i.internal).forEach(i => {
    console.log(`   Network access: http://${i.address}:${PORT}`);
  });
});
