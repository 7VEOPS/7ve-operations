// ============================================================
// DMX STATE ENGINE
// - Holds the full DMX state for both universes (2×512 channels)
// - Applies master dimmer
// - Refreshes at 30fps via Art-Net
// ============================================================

const { FIXTURE_TYPES, PATCH } = require('./fixtures');

const UNIVERSES = 2;
const REFRESH_HZ = 30;

class DmxEngine {
  constructor(artnet) {
    this.artnet = artnet;
    this.masterDimmer = 1.0; // 0.0 – 1.0
    this.blackout = false;

    // Raw channel state: universes[0] = Universe 1 (0-indexed)
    this.universes = [
      new Uint8Array(512),
      new Uint8Array(512),
    ];

    // Build lookup: fixtureId → { universe(0-idx), startAddr(0-idx), type }
    this.fixtureLookup = {};
    for (const p of PATCH) {
      this.fixtureLookup[p.id] = {
        universe: p.universe - 1,  // 0-indexed
        start: p.address - 1,       // 0-indexed
        typeDef: FIXTURE_TYPES[p.type],
        patch: p,
      };
      // Initialize defaults
      const entry = this.fixtureLookup[p.id];
      entry.typeDef.channels.forEach((ch, i) => {
        this.universes[entry.universe][entry.start + i] = ch.default;
      });
    }

    this._interval = null;
  }

  start() {
    if (this._interval) return;
    this._interval = setInterval(() => this._tick(), 1000 / REFRESH_HZ);
    console.log(`[DMX Engine] Running at ${REFRESH_HZ}fps`);
  }

  stop() {
    if (this._interval) { clearInterval(this._interval); this._interval = null; }
  }

  _tick() {
    for (let u = 0; u < UNIVERSES; u++) {
      const raw = this.universes[u];
      if (this.blackout) {
        this.artnet.sendUniverse(u, new Uint8Array(512));
      } else if (this.masterDimmer < 1.0) {
        // Scale dimmer-type channels only
        const scaled = new Uint8Array(raw);
        for (const entry of Object.values(this.fixtureLookup)) {
          if (entry.universe !== u) continue;
          entry.typeDef.channels.forEach((ch, i) => {
            if (ch.type === 'dimmer') {
              scaled[entry.start + i] = Math.round(raw[entry.start + i] * this.masterDimmer);
            }
          });
        }
        this.artnet.sendUniverse(u, scaled);
      } else {
        this.artnet.sendUniverse(u, raw);
      }
    }
  }

  // ── Set individual channel by fixture + channel index ──
  setChannel(fixtureId, channelIndex, value) {
    const entry = this.fixtureLookup[fixtureId];
    if (!entry) return false;
    const v = Math.max(0, Math.min(255, Math.round(value)));
    this.universes[entry.universe][entry.start + channelIndex] = v;
    return true;
  }

  // ── Set all channels for a fixture at once ──
  setFixture(fixtureId, channelValues) {
    // channelValues: { channelIndex: value } or array
    const entry = this.fixtureLookup[fixtureId];
    if (!entry) return false;
    if (Array.isArray(channelValues)) {
      channelValues.forEach((v, i) => {
        if (v !== null && v !== undefined) {
          this.universes[entry.universe][entry.start + i] = Math.max(0, Math.min(255, Math.round(v)));
        }
      });
    } else {
      for (const [idx, v] of Object.entries(channelValues)) {
        this.universes[entry.universe][entry.start + parseInt(idx)] = Math.max(0, Math.min(255, Math.round(v)));
      }
    }
    return true;
  }

  // ── Set a named channel type across a fixture ──
  setFixtureByType(fixtureId, channelType, value) {
    const entry = this.fixtureLookup[fixtureId];
    if (!entry) return false;
    entry.typeDef.channels.forEach((ch, i) => {
      if (ch.type === channelType) {
        this.universes[entry.universe][entry.start + i] = Math.max(0, Math.min(255, Math.round(value)));
      }
    });
    return true;
  }

  // ── Get current values for a fixture ──
  getFixture(fixtureId) {
    const entry = this.fixtureLookup[fixtureId];
    if (!entry) return null;
    const values = [];
    for (let i = 0; i < entry.typeDef.channelCount; i++) {
      values.push(this.universes[entry.universe][entry.start + i]);
    }
    return values;
  }

  // ── Snapshot: get full state ──
  getSnapshot() {
    const fixtures = {};
    for (const id of Object.keys(this.fixtureLookup)) {
      fixtures[id] = this.getFixture(id);
    }
    return { fixtures, master: this.masterDimmer, blackout: this.blackout };
  }

  // ── Restore snapshot ──
  restoreSnapshot(snap) {
    if (snap.master !== undefined) this.masterDimmer = snap.master;
    if (snap.blackout !== undefined) this.blackout = snap.blackout;
    for (const [id, values] of Object.entries(snap.fixtures || {})) {
      this.setFixture(id, values);
    }
  }

  setMaster(value) {
    this.masterDimmer = Math.max(0, Math.min(1, value));
  }

  setBlackout(val) {
    this.blackout = !!val;
    console.log(`[DMX] Blackout: ${this.blackout}`);
  }
}

module.exports = DmxEngine;
