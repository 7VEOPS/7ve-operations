// ============================================================
// FIXTURE DEFINITIONS & PATCH MAP
// ============================================================
// All channel values are 0-255 (DMX standard)
// Addresses are 1-based (DMX standard)

const FIXTURE_TYPES = {

  // ── Martin MAC 250 Entour ── 15ch (16-bit mode)
  'mac250entour': {
    name: 'Martin MAC 250 Entour',
    channelCount: 15,
    channels: [
      { name: 'Shutter/Strobe', type: 'shutter',   default: 32  }, // 20-49 = open
      { name: 'Dimmer',         type: 'dimmer',    default: 0   },
      { name: 'Pan',            type: 'pan',       default: 128 },
      { name: 'Pan Fine',       type: 'pan_fine',  default: 0   },
      { name: 'Tilt',           type: 'tilt',      default: 128 },
      { name: 'Tilt Fine',      type: 'tilt_fine', default: 0   },
      { name: 'Color Wheel',    type: 'color',     default: 0   }, // 0=open, steps 14-255
      { name: 'Gobo Rotate',    type: 'gobo',      default: 0   },
      { name: 'Gobo Rot Index', type: 'raw',       default: 0   },
      { name: 'Gobo Fixed',     type: 'gobo2',     default: 0   },
      { name: 'Focus',          type: 'focus',     default: 128 },
      { name: 'Prism',          type: 'raw',       default: 0   },
      { name: 'Effects Speed',  type: 'speed',     default: 0   },
      { name: 'Pan/Tilt Speed', type: 'speed',     default: 0   },
      { name: 'Reset/Lamp',     type: 'control',   default: 0   },
    ],
    colorWheel: [
      { name: 'Open',   dmx: 0   },
      { name: 'CTC',    dmx: 14  },
      { name: 'Red',    dmx: 28  },
      { name: 'Blue',   dmx: 42  },
      { name: 'Green',  dmx: 56  },
      { name: 'Yellow', dmx: 70  },
      { name: 'Magenta',dmx: 84  },
      { name: 'Cyan',   dmx: 98  },
      { name: 'Orange', dmx: 112 },
      { name: 'Purple', dmx: 126 },
      { name: 'Pink',   dmx: 140 },
      { name: 'Amber',  dmx: 154 },
    ],
    gobos: [
      { name: 'Open',   dmx: 0  },
      { name: 'Gobo 1', dmx: 10 },
      { name: 'Gobo 2', dmx: 20 },
      { name: 'Gobo 3', dmx: 30 },
      { name: 'Gobo 4', dmx: 40 },
      { name: 'Gobo 5', dmx: 50 },
      { name: 'Gobo 6', dmx: 60 },
      { name: 'Gobo 7', dmx: 70 },
    ]
  },

  // ── Shehds 18x18W RGBAUV Wall Wash ── 11ch mode
  'shehds_18x18_wall': {
    name: 'Shehds 18x18 Wall Wash',
    channelCount: 11,
    channels: [
      { name: 'Dimmer',  type: 'dimmer',  default: 0 },
      { name: 'Red',     type: 'red',     default: 0 },
      { name: 'Green',   type: 'green',   default: 0 },
      { name: 'Blue',    type: 'blue',    default: 0 },
      { name: 'Amber',   type: 'amber',   default: 0 },
      { name: 'UV',      type: 'uv',      default: 0 },
      { name: 'White',   type: 'white',   default: 0 },
      { name: 'Strobe',  type: 'strobe',  default: 0 },
      { name: 'Mode',    type: 'control', default: 0 },
      { name: 'Speed',   type: 'speed',   default: 0 },
      { name: 'Dimmer Fine', type: 'raw', default: 0 },
    ]
  },

  // ── Shehds 12x12 Wash Mover ── 9ch mode
  'shehds_12x12_mover': {
    name: 'Shehds 12x12 Wash Mover',
    channelCount: 9,
    channels: [
      { name: 'Pan',    type: 'pan',    default: 128 },
      { name: 'Tilt',   type: 'tilt',   default: 128 },
      { name: 'Speed',  type: 'speed',  default: 0   },
      { name: 'Dimmer', type: 'dimmer', default: 0   },
      { name: 'Red',    type: 'red',    default: 0   },
      { name: 'Green',  type: 'green',  default: 0   },
      { name: 'Blue',   type: 'blue',   default: 0   },
      { name: 'White',  type: 'white',  default: 0   },
      { name: 'Strobe', type: 'strobe', default: 0   },
    ]
  },

  // ── ADJ EZ Par 64 ── 4ch mode
  'ezpar64': {
    name: 'ADJ EZ Par 64',
    channelCount: 4,
    channels: [
      { name: 'Red',    type: 'red',    default: 0 },
      { name: 'Green',  type: 'green',  default: 0 },
      { name: 'Blue',   type: 'blue',   default: 0 },
      { name: 'Dimmer', type: 'dimmer', default: 0 },
    ]
  },

  // ── ADJ Slim Par ── 4ch mode
  'slimpar': {
    name: 'ADJ Slim Par',
    channelCount: 4,
    channels: [
      { name: 'Red',    type: 'red',    default: 0 },
      { name: 'Green',  type: 'green',  default: 0 },
      { name: 'Blue',   type: 'blue',   default: 0 },
      { name: 'Dimmer', type: 'dimmer', default: 0 },
    ]
  },

  // ── Generic DMX Encoder ── 1ch
  'dmx_encoder': {
    name: 'DMX Encoder',
    channelCount: 1,
    channels: [
      { name: 'Value', type: 'dimmer', default: 0 },
    ]
  },

  // ── Fog Machine ── 2ch
  'fog_machine': {
    name: 'Fog Machine',
    channelCount: 2,
    channels: [
      { name: 'Output',   type: 'dimmer', default: 0 },
      { name: 'Duration', type: 'raw',    default: 0 },
    ]
  }
};

// ============================================================
// PATCH — assign each fixture to a universe + start address
// ============================================================
// Universe 1: Movers + Wall Wash = 120 + 44 + 36 = 200ch
// Universe 2: Pars + Encoders + Fog
const PATCH = [
  // ── Universe 1: Moving Heads ──────────────────────────
  { id: 'entour_1',  label: 'Entour 1',  type: 'mac250entour',       universe: 1, address: 1   },
  { id: 'entour_2',  label: 'Entour 2',  type: 'mac250entour',       universe: 1, address: 16  },
  { id: 'entour_3',  label: 'Entour 3',  type: 'mac250entour',       universe: 1, address: 31  },
  { id: 'entour_4',  label: 'Entour 4',  type: 'mac250entour',       universe: 1, address: 46  },
  { id: 'entour_5',  label: 'Entour 5',  type: 'mac250entour',       universe: 1, address: 61  },
  { id: 'entour_6',  label: 'Entour 6',  type: 'mac250entour',       universe: 1, address: 76  },
  { id: 'entour_7',  label: 'Entour 7',  type: 'mac250entour',       universe: 1, address: 91  },
  { id: 'entour_8',  label: 'Entour 8',  type: 'mac250entour',       universe: 1, address: 106 },

  // ── Wall Washes (11ch each → 44ch total) ─────────────
  { id: 'wall_1',    label: 'Wall 1',    type: 'shehds_18x18_wall',  universe: 1, address: 121 },
  { id: 'wall_2',    label: 'Wall 2',    type: 'shehds_18x18_wall',  universe: 1, address: 132 },
  { id: 'wall_3',    label: 'Wall 3',    type: 'shehds_18x18_wall',  universe: 1, address: 143 },
  { id: 'wall_4',    label: 'Wall 4',    type: 'shehds_18x18_wall',  universe: 1, address: 154 },

  // ── Wash Movers (9ch each → 36ch total) ──────────────
  { id: 'mover_1',   label: 'Mover 1',   type: 'shehds_12x12_mover', universe: 1, address: 165 },
  { id: 'mover_2',   label: 'Mover 2',   type: 'shehds_12x12_mover', universe: 1, address: 174 },
  { id: 'mover_3',   label: 'Mover 3',   type: 'shehds_12x12_mover', universe: 1, address: 183 },
  { id: 'mover_4',   label: 'Mover 4',   type: 'shehds_12x12_mover', universe: 1, address: 192 },

  // ── Universe 2: Static Fixtures ───────────────────────
  // EZ Par 64 x27 @ 4ch = 108ch
  { id: 'ezpar_1',   label: 'EZPar 1',   type: 'ezpar64',            universe: 2, address: 1   },
  { id: 'ezpar_2',   label: 'EZPar 2',   type: 'ezpar64',            universe: 2, address: 5   },
  { id: 'ezpar_3',   label: 'EZPar 3',   type: 'ezpar64',            universe: 2, address: 9   },
  { id: 'ezpar_4',   label: 'EZPar 4',   type: 'ezpar64',            universe: 2, address: 13  },
  { id: 'ezpar_5',   label: 'EZPar 5',   type: 'ezpar64',            universe: 2, address: 17  },
  { id: 'ezpar_6',   label: 'EZPar 6',   type: 'ezpar64',            universe: 2, address: 21  },
  { id: 'ezpar_7',   label: 'EZPar 7',   type: 'ezpar64',            universe: 2, address: 25  },
  { id: 'ezpar_8',   label: 'EZPar 8',   type: 'ezpar64',            universe: 2, address: 29  },
  { id: 'ezpar_9',   label: 'EZPar 9',   type: 'ezpar64',            universe: 2, address: 33  },
  { id: 'ezpar_10',  label: 'EZPar 10',  type: 'ezpar64',            universe: 2, address: 37  },
  { id: 'ezpar_11',  label: 'EZPar 11',  type: 'ezpar64',            universe: 2, address: 41  },
  { id: 'ezpar_12',  label: 'EZPar 12',  type: 'ezpar64',            universe: 2, address: 45  },
  { id: 'ezpar_13',  label: 'EZPar 13',  type: 'ezpar64',            universe: 2, address: 49  },
  { id: 'ezpar_14',  label: 'EZPar 14',  type: 'ezpar64',            universe: 2, address: 53  },
  { id: 'ezpar_15',  label: 'EZPar 15',  type: 'ezpar64',            universe: 2, address: 57  },
  { id: 'ezpar_16',  label: 'EZPar 16',  type: 'ezpar64',            universe: 2, address: 61  },
  { id: 'ezpar_17',  label: 'EZPar 17',  type: 'ezpar64',            universe: 2, address: 65  },
  { id: 'ezpar_18',  label: 'EZPar 18',  type: 'ezpar64',            universe: 2, address: 69  },
  { id: 'ezpar_19',  label: 'EZPar 19',  type: 'ezpar64',            universe: 2, address: 73  },
  { id: 'ezpar_20',  label: 'EZPar 20',  type: 'ezpar64',            universe: 2, address: 77  },
  { id: 'ezpar_21',  label: 'EZPar 21',  type: 'ezpar64',            universe: 2, address: 81  },
  { id: 'ezpar_22',  label: 'EZPar 22',  type: 'ezpar64',            universe: 2, address: 85  },
  { id: 'ezpar_23',  label: 'EZPar 23',  type: 'ezpar64',            universe: 2, address: 89  },
  { id: 'ezpar_24',  label: 'EZPar 24',  type: 'ezpar64',            universe: 2, address: 93  },
  { id: 'ezpar_25',  label: 'EZPar 25',  type: 'ezpar64',            universe: 2, address: 97  },
  { id: 'ezpar_26',  label: 'EZPar 26',  type: 'ezpar64',            universe: 2, address: 101 },
  { id: 'ezpar_27',  label: 'EZPar 27',  type: 'ezpar64',            universe: 2, address: 105 },

  // Slim Par x8 @ 4ch = 32ch (addresses 109-140)
  { id: 'slimpar_1', label: 'Slim 1',    type: 'slimpar',            universe: 2, address: 109 },
  { id: 'slimpar_2', label: 'Slim 2',    type: 'slimpar',            universe: 2, address: 113 },
  { id: 'slimpar_3', label: 'Slim 3',    type: 'slimpar',            universe: 2, address: 117 },
  { id: 'slimpar_4', label: 'Slim 4',    type: 'slimpar',            universe: 2, address: 121 },
  { id: 'slimpar_5', label: 'Slim 5',    type: 'slimpar',            universe: 2, address: 125 },
  { id: 'slimpar_6', label: 'Slim 6',    type: 'slimpar',            universe: 2, address: 129 },
  { id: 'slimpar_7', label: 'Slim 7',    type: 'slimpar',            universe: 2, address: 133 },
  { id: 'slimpar_8', label: 'Slim 8',    type: 'slimpar',            universe: 2, address: 137 },

  // DMX Encoders x2
  { id: 'encoder_1', label: 'Encoder 1', type: 'dmx_encoder',        universe: 2, address: 141 },
  { id: 'encoder_2', label: 'Encoder 2', type: 'dmx_encoder',        universe: 2, address: 142 },

  // Fog Machine
  { id: 'fog_1',     label: 'Fog',       type: 'fog_machine',        universe: 2, address: 143 },
];

// Default groups
const DEFAULT_GROUPS = [
  { id: 'grp_entours',  name: 'All Entours',    fixtureIds: ['entour_1','entour_2','entour_3','entour_4','entour_5','entour_6','entour_7','entour_8'] },
  { id: 'grp_walls',    name: 'Wall Washes',     fixtureIds: ['wall_1','wall_2','wall_3','wall_4'] },
  { id: 'grp_movers',   name: 'Wash Movers',     fixtureIds: ['mover_1','mover_2','mover_3','mover_4'] },
  { id: 'grp_ezpars',   name: 'All EZ Pars',     fixtureIds: ['ezpar_1','ezpar_2','ezpar_3','ezpar_4','ezpar_5','ezpar_6','ezpar_7','ezpar_8','ezpar_9','ezpar_10','ezpar_11','ezpar_12','ezpar_13','ezpar_14','ezpar_15','ezpar_16','ezpar_17','ezpar_18','ezpar_19','ezpar_20','ezpar_21','ezpar_22','ezpar_23','ezpar_24','ezpar_25','ezpar_26','ezpar_27'] },
  { id: 'grp_slims',    name: 'Slim Pars',       fixtureIds: ['slimpar_1','slimpar_2','slimpar_3','slimpar_4','slimpar_5','slimpar_6','slimpar_7','slimpar_8'] },
  { id: 'grp_allpars',  name: 'All Pars',        fixtureIds: ['ezpar_1','ezpar_2','ezpar_3','ezpar_4','ezpar_5','ezpar_6','ezpar_7','ezpar_8','ezpar_9','ezpar_10','ezpar_11','ezpar_12','ezpar_13','ezpar_14','ezpar_15','ezpar_16','ezpar_17','ezpar_18','ezpar_19','ezpar_20','ezpar_21','ezpar_22','ezpar_23','ezpar_24','ezpar_25','ezpar_26','ezpar_27','slimpar_1','slimpar_2','slimpar_3','slimpar_4','slimpar_5','slimpar_6','slimpar_7','slimpar_8'] },
  { id: 'grp_allmove',  name: 'All Movers',      fixtureIds: ['entour_1','entour_2','entour_3','entour_4','entour_5','entour_6','entour_7','entour_8','mover_1','mover_2','mover_3','mover_4'] },
  { id: 'grp_all',      name: 'All Fixtures',    fixtureIds: PATCH.map(f => f.id) },
];

module.exports = { FIXTURE_TYPES, PATCH, DEFAULT_GROUPS };
