# CTRL DMX — Local Lighting Controller

Custom web-based DMX lighting controller. Runs on your PC, control from iPad or any browser on the same network.

---

## HARDWARE REQUIRED

Replace the ADJ MyDMX Go with a WiFi Art-Net node. Recommended:

| Option | Price | Notes |
|--------|-------|-------|
| **ENTTEC WIFI DMX PRO** | ~$150 | Most reliable, battle-tested |
| **Pknight EasyNode** | ~$35 | Budget, works well |
| **Lixada WiFi DMX** | ~$30 | Budget option |

Any device that supports **Art-Net** (UDP port 6454) and connects to WiFi will work.

---

## INSTALLATION

### 1. Install Node.js
Download from https://nodejs.org (LTS version)

### 2. Install dependencies
```bash
cd dmx-controller
npm install
```

### 3. Start the server
```bash
npm start
```

You'll see output like:
```
╔══════════════════════════════════════╗
║   DMX CONTROLLER SERVER              ║
║   http://localhost:3000              ║
╚══════════════════════════════════════╝

   Network access: http://192.168.1.45:3000
```

### 4. Open on iPad
Connect your iPad to the **same WiFi network** as the PC running the server.  
Open Safari and go to: `http://192.168.1.45:3000` (use the IP shown above)

---

## NETWORK SETUP

### Art-Net Node Setup
1. Power on your Art-Net WiFi node
2. Connect it to your show WiFi (router, or use a travel router)
3. Connect your PC to the **same** WiFi network
4. Find the node's IP address (check your router's device list)
5. In the app → CONFIG tab → enter the node's IP address
6. Hit SAVE CONFIG

### Recommended show network
Use a dedicated travel router (TP-Link TL-WR902AC, ~$30) for a clean, interference-free show network.

---

## FIXTURE PATCH

Your rig is pre-patched:

**Universe 1**
| Fixture | Count | Mode | Addresses |
|---------|-------|------|-----------|
| Martin MAC 250 Entour | 8 | 15ch | 1–120 |
| Shehds 18x18 Wall Wash | 4 | 11ch | 121–164 |
| Shehds 12x12 Wash Mover | 4 | 9ch | 165–200 |

**Universe 2**
| Fixture | Count | Mode | Addresses |
|---------|-------|------|-----------|
| ADJ EZ Par 64 | 27 | 4ch | 1–108 |
| ADJ Slim Par | 8 | 4ch | 109–140 |
| DMX Encoder | 2 | 1ch | 141–142 |
| Fog Machine | 1 | 2ch | 143–144 |

### Addressing your fixtures
Set each fixture's DMX start address to match the patch above using its front panel.

---

## USAGE

### Groups tab
- Master dimmer per group
- Quick color buttons (Red, Green, Blue, Cyan, Magenta, Amber, White, UV…)
- Best for fast show control

### Fixtures tab  
- Individual fixture control
- All channels exposed as vertical faders
- Color wheel + gobo wheel buttons for Mac Entours

### Movers tab
- XY touch pad for pan/tilt (touch and drag)
- Per-fixture channel faders for dimmer, color, gobo, etc.

### Scenes tab
- Type a name and hit SAVE to capture current look
- GO to recall instantly
- UPD to overwrite an existing scene

### Config tab
- Set your Art-Net node's IP
- View the full patch summary

---

## BLACKOUT
Big red BLK button at the top. Sends all zeros to all channels. Hit again to restore.

## MASTER DIMMER
Scales all dimmer channels globally. Does not affect position, color wheel, or gobo.

---

## TROUBLESHOOTING

**Lights not responding**
- Check Art-Net IP in CONFIG tab matches your node
- Make sure PC and node are on the same network
- Try broadcast IP: `2.255.255.255`
- Try the node's subnet broadcast: e.g. `192.168.1.255`

**App not loading on iPad**
- Make sure both iPad and PC are on the same WiFi
- Use the IP shown in the server terminal, not `localhost`
- Try disabling firewall on the PC temporarily

**Latency on faders**
- Use unicast (specific node IP) instead of broadcast
- Make sure you're on 2.4GHz or 5GHz WiFi, not both

---

## AUTO-START ON WINDOWS

To have the server start automatically with Windows:
1. Create a file `start-dmx.bat`:
   ```
   cd C:\path\to\dmx-controller
   node server\index.js
   ```
2. Add a shortcut to it in: `Shell:startup` (Win+R, type that)

---

## CUSTOMIZING FIXTURES

Edit `server/fixtures.js` to:
- Change DMX addresses
- Add new fixture types
- Modify channel counts/modes
- Create default groups
